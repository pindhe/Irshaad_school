export enum UserRole {
  ADMIN = 'Administrator',
  ADMIN_LIMITED = 'Admin',
  PRINCIPAL = 'Principal',
  TEACHER = 'Teacher',
  ACCOUNTANT = 'Accountant',
  LIBRARIAN = 'Librarian',
  REGISTRAR = 'Registrar'
}

export interface User {
  id: string;
  username: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  email: string;
  isActive: boolean;
  avatarUrl?: string;
}

export interface Class {
  id: string;
  className: string; // e.g., Grade 9, Grade 10
  academicYear: string;
}

export interface Section {
  id: string;
  classId: string;
  sectionName: string; // e.g., A, B, C
}

export interface Student {
  id: string; // Unique student ID, e.g., AL-2026-0001
  firstName: string;
  middleName: string;
  lastName: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female';
  address: string;
  city: string;
  parentName: string;
  parentContact: string;
  parentEmail: string;
  admissionDate: string;
  classId: string;
  sectionId: string;
  isActive: boolean;
}

export interface Staff {
  id: string; // e.g., ST-001
  firstName: string;
  lastName: string;
  gender: 'Male' | 'Female';
  contactNumber: string;
  email: string;
  employmentDate: string;
  designation: string; // e.g., 'Physics Teacher', 'Math Teacher', 'Head of Department'
  isActive: boolean;
  subjectsTaught: string[]; // Subject IDs
}

export interface Subject {
  id: string;
  subjectName: string;
  subjectCode: string;
}

export enum AttendanceStatus {
  PRESENT = 'Present',
  ABSENT = 'Absent',
  LATE = 'Late',
  EXCUSED = 'Excused'
}

export interface StudentAttendance {
  id: string;
  studentId: string;
  date: string;
  status: AttendanceStatus;
  remarks?: string;
  recordedBy: string; // Username/ID
  timestamp: string;
}

export interface Exam {
  id: string;
  examName: string; // e.g., Mid-term, Final Exam, Quiz 1
  subjectId: string;
  classId: string;
  maxMarks: number;
  examDate: string;
}

export interface Mark {
  id: string;
  studentId: string;
  examId: string;
  subjectId: string;
  marksObtained: number;
  grade: string;
  remarks?: string;
  recordedBy: string;
  timestamp: string;
}

export interface FeeCategory {
  id: string;
  categoryName: string; // e.g., Tuition Fee, Library Fee, Exam Fee, Sports Fee
}

export interface FeeStructure {
  id: string;
  classId: string;
  categoryId: string;
  amount: number;
  academicYear: string;
}

export interface Payment {
  id: string;
  studentId: string;
  categoryId: string;
  amountPaid: number;
  paymentDate: string;
  paymentMethod: 'Cash' | 'Bank Transfer' | 'Mobile Money';
  receivedBy: string;
  remarks?: string;
  receiptNumber: string; // Unique
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  publisher: string;
  publicationYear: number;
  category: string;
  totalQuantity: number;
  availableQuantity: number;
}

export interface Borrowing {
  id: string;
  bookId: string;
  studentId: string;
  issueDate: string;
  dueDate: string;
  returnDate?: string;
  isReturned: boolean;
  issuedBy: string;
}

export interface TimetableEntry {
  id: string;
  classId: string;
  dayOfWeek: string; // e.g., Monday, Tuesday, ...
  periodNumber: number; // 1, 2, 3, 4, 5, 6
  startTime: string; // e.g., '08:00'
  endTime: string; // e.g., '08:45'
  subjectId: string;
  teacherId: string;
  roomNumber?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userRole: UserRole;
  action: string;
  tableName: string;
  recordId: string;
  oldValue?: string;
  newValue?: string;
  timestamp: string;
}

export interface SchoolSettings {
  schoolName: string;
  academicYear: string;
  address: string;
  phone: string;
  email: string;
  gradingScale: {
    grade: string;
    minPercentage: number;
  }[];
}
