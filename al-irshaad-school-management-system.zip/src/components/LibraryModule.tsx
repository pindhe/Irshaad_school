import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  X, 
  Check, 
  AlertCircle, 
  Calendar, 
  User, 
  Bookmark,
  Activity,
  PlusCircle,
  FileText,
  Trash2
} from 'lucide-react';
import { Book, Borrowing, Student, User as UserType, UserRole } from '../types';

interface LibraryModuleProps {
  books: Book[];
  borrowings: Borrowing[];
  students: Student[];
  activeUser: UserType;
  onAddBook: (book: Omit<Book, 'id' | 'availableQuantity'>) => void;
  onIssueBook: (borrowing: Omit<Borrowing, 'id' | 'isReturned'>) => void;
  onReturnBook: (borrowingId: string) => void;
  onDeleteBook: (id: string) => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

export default function LibraryModule({
  books,
  borrowings,
  students,
  activeUser,
  onAddBook,
  onIssueBook,
  onReturnBook,
  onDeleteBook,
  onLogAction
}: LibraryModuleProps) {
  const [activeTab, setActiveTab] = useState<'catalog' | 'borrowings' | 'add'>('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states for Issue Book
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [issueBookId, setIssueBookId] = useState('');
  const [issueStudentId, setIssueStudentId] = useState('');
  const [issueDays, setIssueDays] = useState(14);
  const [issueError, setIssueError] = useState('');

  // Form states for Add Book
  const [bookTitle, setBookTitle] = useState('');
  const [bookAuthor, setBookAuthor] = useState('');
  const [bookIsbn, setBookIsbn] = useState('');
  const [bookPublisher, setBookPublisher] = useState('');
  const [bookPublishedYear, setBookPublishedYear] = useState<number>(2020);
  const [bookCategory, setBookCategory] = useState('Physics');
  const [bookQty, setBookQty] = useState<number>(5);

  const getStudentName = (sid: string) => {
    const s = students.find(st => st.id === sid);
    return s ? `${s.firstName} ${s.middleName} ${s.lastName}` : 'Unknown student';
  };

  const getBookTitle = (bid: string) => {
    return books.find(b => b.id === bid)?.title || 'Unknown Asset';
  };

  // Check if a borrowing is currently Overdue
  // Today's context from metadata: 2026-06-01
  const isBorrowingOverdue = (borrowing: Borrowing) => {
    if (borrowing.isReturned) return false;
    const systemToday = new Date('2026-06-01');
    const due = new Date(borrowing.dueDate);
    return due < systemToday;
  };

  // Filters
  const filteredBooks = books.filter(b => {
    const term = searchQuery.toLowerCase();
    return b.title.toLowerCase().includes(term) || 
           b.author.toLowerCase().includes(term) || 
           b.isbn.toLowerCase().includes(term) || 
           b.category.toLowerCase().includes(term);
  });

  const activeCheckouts = borrowings.filter(borrow => {
    const term = searchQuery.toLowerCase();
    const studName = getStudentName(borrow.studentId).toLowerCase();
    const bTitle = getBookTitle(borrow.bookId).toLowerCase();
    return studName.includes(term) || bTitle.includes(term) || borrow.id.toLowerCase().includes(term);
  });

  // Event handlers
  const handleIssueBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!issueBookId || !issueStudentId) {
      setIssueError('Please choose target book and student.');
      return;
    }

    // Verify stock availability
    const targetBook = books.find(b => b.id === issueBookId);
    if (!targetBook || targetBook.availableQuantity <= 0) {
      setIssueError('Selected library asset is currently out of stock.');
      return;
    }

    // Calculate dates
    const today = new Date();
    const issueDateStr = today.toISOString().split('T')[0];
    const dueDate = new Date();
    dueDate.setDate(today.getDate() + issueDays);
    const dueDateStr = dueDate.toISOString().split('T')[0];

    onIssueBook({
      bookId: issueBookId,
      studentId: issueStudentId,
      issueDate: issueDateStr,
      dueDate: dueDateStr,
      issuedBy: activeUser.username
    });

    onLogAction(
      'ISSUE_LIBRARY_BOOK',
      'Borrowings',
      issueStudentId,
      `Issued book "${targetBook.title}" to student ID ${issueStudentId} (Due: ${dueDateStr})`
    );

    setSuccessMsg('Book checked out successfully close register.');
    setIsIssueModalOpen(false);
    setIssueStudentId('');
    setIssueBookId('');
    setIssueError('');
    setTimeout(() => setSuccessMsg(''), 4500);
  };

  const handleReturnBookAction = (borrowId: string) => {
    onReturnBook(borrowId);
    setSuccessMsg('Book registered returned checked in stock updated!');
    onLogAction(
      'RETURN_LIBRARY_BOOK',
      'Borrowings',
      borrowId,
      `Returned book reference item ID ${borrowId}`
    );
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const handleAddBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookTitle || !bookAuthor || !bookIsbn) {
      setSuccessMsg('Include necessary identifiers.');
      return;
    }

    onAddBook({
      title: bookTitle,
      author: bookAuthor,
      isbn: bookIsbn,
      publisher: bookPublisher,
      publicationYear: bookPublishedYear,
      category: bookCategory,
      totalQuantity: bookQty
    });

    onLogAction(
      'ADD_LIBRARY_BOOK',
      'Books',
      bookIsbn,
      `Added new library title asset "${bookTitle}"`
    );

    setSuccessMsg('Scholarly title added to local catalog.');
    setActiveTab('catalog');
    
    // Reset Form
    setBookTitle('');
    setBookAuthor('');
    setBookIsbn('');
    setBookPublisher('');
    setBookQty(5);
    setTimeout(() => setSuccessMsg(''), 4500);
  };

  const totalOverdueCheckouts = borrowings.filter(b => isBorrowingOverdue(b)).length;

  return (
    <div className="space-y-6">
      {/* Tab bar header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-3 gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">Library Cataloging</h1>
          <p className="text-sm text-gray-500 mt-1">Audit school academic library references, manage borrower accounts, and overdue alerts.</p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => { setActiveTab('catalog'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'catalog' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Ref Books Catalog
          </button>
          <button
            onClick={() => { setActiveTab('borrowings'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'borrowings' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Borrowings Checklist {totalOverdueCheckouts > 0 && (
              <span className="bg-red-500 text-white text-[9.5px] font-extrabold px-1.5 rounded-full ml-1">
                {totalOverdueCheckouts} Overdue
              </span>
            )}
          </button>
          <button
            onClick={() => { setActiveTab('add'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'add' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Onboard New Title
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-xl max-w-4xl mx-auto">
          {successMsg}
        </div>
      )}

      {/* VIEW ROADS CHOOSE */}
      {activeTab === 'catalog' && (
        <div className="space-y-4 animate-in fade-in duration-250">
          <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-xs space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="relative w-full max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={17} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter key identifier book title, category..."
                  className="w-full pl-9 pr-4 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden"
                />
              </div>

              <button
                type="button"
                onClick={() => setIsIssueModalOpen(true)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer inline-flex items-center gap-1"
              >
                <PlusCircle size={14} />
                <span>Issue Asset</span>
              </button>
            </div>

            {/* Books catalog inventory frame */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredBooks.map(book => (
                <div key={book.id} className="bg-slate-50/50 border border-slate-150 p-4 rounded-xl relative space-y-3 shadow-3xs hover:bg-white hover:shadow-xs transition-all">
                  <span className="text-[9px] uppercase tracking-wider font-extrabold bg-slate-200/50 text-slate-700 px-2 py-0.5 rounded-full absolute top-4 right-4">
                    {book.category}
                  </span>
                  
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-gray-900 text-sm tracking-tight leading-snug pr-12">{book.title}</h4>
                    <p className="text-xs text-gray-400 font-medium">By {book.author}</p>
                  </div>

                  <div className="text-xs text-gray-500 font-mono space-y-0.5 leading-snug">
                    <p>ISBN Reference: <span className="text-slate-800 font-semibold">{book.isbn}</span></p>
                    <p>Publisher: <span className="text-gray-700">{book.publisher}</span></p>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-100 text-[11px]">
                    <span className="font-semibold text-gray-400">Available:</span>
                    <span className={`font-bold font-mono px-2 py-0.5 rounded ${
                      book.availableQuantity > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-650'
                    }`}>
                      {book.availableQuantity} / {book.totalQuantity} Units
                    </span>
                  </div>

                  {/* Deletion button with RBAC checks */}
                  <div className="pt-2 border-t border-slate-100 flex justify-end">
                    {activeUser.role === UserRole.ADMIN_LIMITED ? (
                      <button
                        type="button"
                        onClick={() => alert(`Access Denied: Your Admin account is configured with Add/Update permissions only. Permanent deletion of '${book.title}' is restricted to Administrators.`)}
                        className="text-slate-400 hover:text-amber-600 p-1.5 rounded-lg hover:bg-amber-50 cursor-pointer transition-all flex items-center gap-1 text-[10px] font-bold"
                        title="Delete restricted for Admin role"
                      >
                        <Trash2 size={12} className="opacity-60" />
                        <span>Delete (Locked)</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`Are you absolutely sure you want to permanently delete '${book.title}' from the library book register?`)) {
                            onDeleteBook(book.id);
                            onLogAction('BOOK_DELETION', 'Books', book.id, `Permanently deleted book catalog record: '${book.title}'`);
                          }
                        }}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-lg cursor-pointer transition-all flex items-center gap-1 text-[10px] font-bold"
                        title="Delete book record"
                      >
                        <Trash2 size={12} />
                        <span>Delete Asset</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'borrowings' && (
        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-4 mb-4">
            <h3 className="font-semibold text-gray-800 text-sm">Active Book Borrowings logs</h3>
            <p className="text-xs text-gray-400 mt-1">System context date is evaluated as <strong className="text-slate-900 font-mono font-bold">2026-06-01</strong> for overdue audits.</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-gray-150 text-[10px] text-[#94a3b8] font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3">BorrowID</th>
                  <th className="py-2.5 px-3">Reference Asset</th>
                  <th className="py-2.5 px-3">Borrower Student</th>
                  <th className="py-2.5 px-3">Date Borrowed</th>
                  <th className="py-2.5 px-3">Due Dateline</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Receipt Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-xs leading-relaxed">
                {activeCheckouts.map(borrow => {
                  const overdue = isBorrowingOverdue(borrow);
                  return (
                    <tr key={borrow.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-3 font-mono font-bold text-gray-400">{borrow.id}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{getBookTitle(borrow.bookId)}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-800">
                        {getStudentName(borrow.studentId)}
                        <span className="text-[10px] text-gray-400 font-mono block mt-0.5">{borrow.studentId}</span>
                      </td>
                      <td className="py-2.5 px-3 text-gray-500 font-mono">{borrow.issueDate}</td>
                      <td className="py-2.5 px-3 text-slate-800 font-mono font-medium">{borrow.dueDate}</td>
                      <td className="py-2.5 px-3">
                        {borrow.isReturned ? (
                          <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-semibold text-[10.5px]">Checked In</span>
                        ) : overdue ? (
                          <span className="bg-red-50 text-red-600 px-1.5 py-0.5 rounded font-extrabold text-[10.5px] inline-flex items-center gap-1">
                            <AlertCircle size={10} />
                            <span>Overdue Account</span>
                          </span>
                        ) : (
                          <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-bold text-[10.5px]">With Pupil</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {!borrow.isReturned && (
                          <button
                            type="button"
                            onClick={() => handleReturnBookAction(borrow.id)}
                            className="bg-slate-900 hover:bg-slate-800 text-white px-2 py-1 cursor-pointer font-bold text-[10px] rounded transition-all"
                          >
                            Return Book
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'add' && (
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm max-w-xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-3 mb-4">
            <h3 className="font-semibold text-gray-800 text-sm">Catalog New Scholarly Asset</h3>
            <p className="text-xs text-gray-400 mt-0.5">Input book identifiers to update library indexes.</p>
          </div>

          <form onSubmit={handleAddBookSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase">Book Title *</label>
              <input
                type="text"
                required
                value={bookTitle}
                onChange={(e) => setBookTitle(e.target.value)}
                placeholder="e.g. Inorganic Chemistry fundamentals"
                className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline bg-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Author Name *</label>
                <input
                  type="text"
                  required
                  value={bookAuthor}
                  onChange={(e) => setBookAuthor(e.target.value)}
                  placeholder="e.g. Dr. Amina Said"
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">ISBN Number *</label>
                <input
                  type="text"
                  required
                  value={bookIsbn}
                  onChange={(e) => setBookIsbn(e.target.value)}
                  placeholder="e.g. 978-3-16-148410-0"
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-gray-500 uppercase">Publisher</label>
                <input
                  type="text"
                  value={bookPublisher}
                  onChange={(e) => setBookPublisher(e.target.value)}
                  placeholder="Cengage"
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-gray-500 uppercase">Category Area *</label>
                <select
                  value={bookCategory}
                  onChange={(e) => setBookCategory(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
                >
                  <option value="Physics">Physics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Biology">Biology</option>
                  <option value="Islamic Studies">Islamic Studies</option>
                  <option value="Arabic">Arabic</option>
                  <option value="General Literature">General Literature</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-gray-400 uppercase">Available Qty *</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={bookQty}
                  onChange={(e) => setBookQty(parseInt(e.target.value) || 5)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded font-mono font-bold"
                />
              </div>
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-5 py-2 rounded-lg transition-colors cursor-pointer"
              >
                Register Asset
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ISSUE BOOK VOUCHER DIALOG */}
      {isIssueModalOpen && (
        <div className="fixed inset-0 bg-black/45 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-gray-100 w-full max-w-sm overflow-hidden animate-in fade-in duration-150">
            <div className="bg-slate-50 border-b border-gray-150 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bookmark className="text-slate-800" size={16} />
                <h3 className="font-semibold text-gray-900 text-sm">Issue Library Asset</h3>
              </div>
              <button onClick={() => setIsIssueModalOpen(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleIssueBookSubmit} className="p-5 space-y-4">
              {issueError && (
                <div className="p-2.5 bg-red-50 border border-red-50 text-red-600 text-xs font-semibold rounded">
                  {issueError}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Book Target *</label>
                <select
                  required
                  value={issueBookId}
                  onChange={(e) => setIssueBookId(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white text-gray-850"
                >
                  <option value="">Choose Ref Volume</option>
                  {books.map(b => (
                    <option key={b.id} value={b.id} disabled={b.availableQuantity <= 0}>
                      {b.title} ({b.availableQuantity} available)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Target Student *</label>
                <select
                  required
                  value={issueStudentId}
                  onChange={(e) => setIssueStudentId(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg bg-white"
                >
                  <option value="">Select Borrower Student</option>
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.middleName} {s.lastName} ({s.id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Maximum Borrower Span</label>
                <select
                  value={issueDays}
                  onChange={(e) => setIssueDays(parseInt(e.target.value))}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
                >
                  <option value={7}>7 Days (1 Week)</option>
                  <option value={14}>14 Days (2 Weeks)</option>
                  <option value={21}>21 Days (3 Weeks)</option>
                  <option value={30}>30 Days (1 Month)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                <button
                  type="button"
                  onClick={() => setIsIssueModalOpen(false)}
                  className="px-4 py-1.5 text-xs text-gray-500 bg-gray-100 rounded hover:bg-gray-200 cursor-pointer"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded cursor-pointer font-extrabold"
                >
                  Authorise Issuance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
