import React, { useState, useRef } from 'react';
import { 
  FileText, 
  UserCheck, 
  Award, 
  Calendar, 
  Search, 
  Printer, 
  Plus, 
  X, 
  Clock, 
  Check, 
  GraduationCap, 
  BookOpen, 
  CheckCircle,
  FileSpreadsheet,
  TrendingUp,
  Percent,
  BadgeAlert
} from 'lucide-react';
import { 
  Student, 
  Class, 
  Section, 
  Subject, 
  StudentAttendance, 
  AttendanceStatus, 
  Exam, 
  Mark, 
  User, 
  SchoolSettings 
} from '../types';

interface AcademicModuleProps {
  students: Student[];
  classes: Class[];
  sections: Section[];
  subjects: Subject[];
  exams: Exam[];
  marks: Mark[];
  attendanceLogs: StudentAttendance[];
  activeUser: User;
  schoolSettings: SchoolSettings;
  onRecordAttendance: (records: Omit<StudentAttendance, 'id' | 'timestamp'>[]) => void;
  onRecordMarks: (marksEntry: Omit<Mark, 'id' | 'timestamp'>[]) => void;
  onAddExam: (exam: Omit<Exam, 'id'>) => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

export default function AcademicModule({
  students,
  classes,
  sections,
  subjects,
  exams,
  marks,
  attendanceLogs,
  activeUser,
  schoolSettings,
  onRecordAttendance,
  onRecordMarks,
  onAddExam,
  onLogAction
}: AcademicModuleProps) {
  const [activeTab, setActiveTab] = useState<'attendance' | 'grading' | 'reportCard' | 'timetable'>('attendance');
  const [successMsg, setSuccessMsg] = useState('');

  // 1. ATTENDANCE REGISTER STATE
  const [attClassId, setAttClassId] = useState(classes[0]?.id || '');
  const [attSectionId, setAttSectionId] = useState('');
  const [attDate, setAttDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [attendanceSheet, setAttendanceSheet] = useState<{ studentId: string; name: string; status: AttendanceStatus; remarks: string }[]>([]);

  // Initialize or fetch attendance list for specified criteria
  const handleLoadAttendanceSheet = () => {
    if (!attClassId || !attSectionId) return;
    
    // Filter students by class and section
    const targetStudents = students.filter(s => s.classId === attClassId && s.sectionId === attSectionId && s.isActive);
    
    // Pre-populate sheet. If there's an existing record for this date and students, load that instead of default PRESENT
    const sheet = targetStudents.map(student => {
      const existing = attendanceLogs.find(log => log.studentId === student.id && log.date === attDate);
      return {
        studentId: student.id,
        name: `${student.firstName} ${student.middleName} ${student.lastName}`,
        status: existing ? existing.status : AttendanceStatus.PRESENT,
        remarks: existing?.remarks || ''
      };
    });
    setAttendanceSheet(sheet);
    setSuccessMsg('');
  };

  const handleUpdateRecordStatus = (idx: number, status: AttendanceStatus) => {
    const updated = [...attendanceSheet];
    updated[idx].status = status;
    setAttendanceSheet(updated);
  };

  const handleUpdateRecordRemarks = (idx: number, notes: string) => {
    const updated = [...attendanceSheet];
    updated[idx].remarks = notes;
    setAttendanceSheet(updated);
  };

  const handleSaveAttendanceSheet = (e: React.FormEvent) => {
    e.preventDefault();
    if (attendanceSheet.length === 0) return;

    const formatted = attendanceSheet.map(item => ({
      studentId: item.studentId,
      date: attDate,
      status: item.status,
      remarks: item.remarks || undefined,
      recordedBy: activeUser.username
    }));

    onRecordAttendance(formatted);
    setSuccessMsg('Student attendance register recorded successfully!');
    onLogAction(
      'RECORD_STUDENT_ATTENDANCE',
      'StudentAttendance',
      attDate,
      `Recorded daily attendance of ${attendanceSheet.length} students in ${getClassName(attClassId)} - ${getSectionName(attSectionId)}`
    );
    setTimeout(() => setSuccessMsg(''), 4000);
  };


  // 2. EXAM GRADING MODULE STATE
  const [gradeClassId, setGradeClassId] = useState(classes[0]?.id || '');
  const [gradeSubjectId, setGradeSubjectId] = useState(subjects[0]?.id || '');
  const [gradeExamName, setGradeExamName] = useState('Mid-term Exam');
  const [gradeMaxMarks, setGradeMaxMarks] = useState(100);
  const [gradeDate, setGradeDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [marksEntryList, setMarksEntryList] = useState<{ studentId: string; name: string; marksObtained: number; remarks: string }[]>([]);

  // Grading calculation logic
  const calculateGradeFromMarks = (obtained: number, total: number) => {
    const pct = (obtained / total) * 100;
    const scale = schoolSettings.gradingScale;
    
    // Iterate from top score threshold to lowest
    const sortedScale = [...scale].sort((a, b) => b.minPercentage - a.minPercentage);
    for (const scoreItem of sortedScale) {
      if (pct >= scoreItem.minPercentage) {
        return scoreItem.grade;
      }
    }
    return 'F';
  };

  const handleLoadMarksSheet = () => {
    if (!gradeClassId || !gradeSubjectId) return;

    // Filter students
    const targetStudents = students.filter(s => s.classId === gradeClassId && s.isActive);
    
    // Find if an exam matching class, subject, and template exam exists
    let examRef = exams.find(e => e.classId === gradeClassId && e.subjectId === gradeSubjectId && e.examName === gradeExamName);

    const baseEntries = targetStudents.map(student => {
      let markValue = 0;
      let notes = '';
      if (examRef) {
        const recordedMark = marks.find(m => m.studentId === student.id && m.examId === examRef!.id);
        if (recordedMark) {
          markValue = recordedMark.marksObtained;
          notes = recordedMark.remarks || '';
        }
      }
      return {
        studentId: student.id,
        name: `${student.firstName} ${student.middleName} ${student.lastName}`,
        marksObtained: markValue,
        remarks: notes
      };
    });
    setMarksEntryList(baseEntries);
    setSuccessMsg('');
  };

  const handleUpdateObtainedMarks = (idx: number, rawVal: string) => {
    let val = parseFloat(rawVal) || 0;
    if (val < 0) val = 0;
    if (val > gradeMaxMarks) val = gradeMaxMarks;
    const updated = [...marksEntryList];
    updated[idx].marksObtained = val;
    setMarksEntryList(updated);
  };

  const handleUpdateMarksRemarks = (idx: number, text: string) => {
    const updated = [...marksEntryList];
    updated[idx].remarks = text;
    setMarksEntryList(updated);
  };

  const handleSaveMarksSheet = (e: React.FormEvent) => {
    e.preventDefault();
    if (marksEntryList.length === 0) return;

    // Check if exam already exists, else dynamically append exam to master registry
    let examRef = exams.find(ex => ex.classId === gradeClassId && ex.subjectId === gradeSubjectId && ex.examName === gradeExamName);
    
    let targetExamId = '';
    if (!examRef) {
      // Create new exam object
      const newExam = {
        examName: gradeExamName,
        subjectId: gradeSubjectId,
        classId: gradeClassId,
        maxMarks: gradeMaxMarks,
        examDate: gradeDate
      };
      
      onAddExam(newExam);
      // Wait for app status refresh or simulate generated key
      targetExamId = `EX-${Date.now()}`;
    } else {
      targetExamId = examRef.id;
    }

    const marksToInsert = marksEntryList.map(item => ({
      studentId: item.studentId,
      examId: targetExamId,
      subjectId: gradeSubjectId,
      marksObtained: item.marksObtained,
      grade: calculateGradeFromMarks(item.marksObtained, gradeMaxMarks),
      remarks: item.remarks || undefined,
      recordedBy: activeUser.username
    }));

    onRecordMarks(marksToInsert);
    setSuccessMsg('Academic gradesheet records saved successfully!');
    onLogAction(
      'RECORD_EXAM_MARKS',
      'Marks',
      targetExamId,
      `Recorded exam scores of ${marksEntryList.length} students for ${gradeExamName} in ${getSubjectName(gradeSubjectId)}`
    );
    setTimeout(() => setSuccessMsg(''), 4000);
  };


  // 3. REPORT CARD GENERATION STATE
  const [reportStudentId, setReportStudentId] = useState('');
  const [isReportGenerated, setIsReportGenerated] = useState(false);
  const printableAreaRef = useRef<HTMLDivElement>(null);

  const getStudentByUuid = (id: string) => students.find(s => s.id === id);

  const handleGenerateReportCard = () => {
    if (!reportStudentId) return;
    setIsReportGenerated(true);
    onLogAction(
      'GENERATE_REPORT_CARD',
      'Reports',
      reportStudentId,
      `Generated scholarly performance report card transcript for student ID ${reportStudentId}`
    );
  };

  // Compile transcripts
  const selectedStudentObj = getStudentByUuid(reportStudentId);
  const studentMarks = marks.filter(m => m.studentId === reportStudentId);
  const studentAttendance = attendanceLogs.filter(a => a.studentId === reportStudentId);

  // Math metrics
  const totalDays = studentAttendance.length;
  const presentDays = studentAttendance.filter(a => a.status === AttendanceStatus.PRESENT).length;
  const attendanceRatePercentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 100;

  // Compile exam marks with subject definitions
  const compiledTranscripts = studentMarks.map(mark => {
    const matchedSubject = subjects.find(s => s.id === mark.subjectId);
    const matchedExam = exams.find(e => e.id === mark.examId);
    return {
      id: mark.id,
      subjectName: matchedSubject?.subjectName || 'General Subject',
      examName: matchedExam?.examName || 'Assessment',
      maxMarks: matchedExam?.maxMarks || 100,
      obtained: mark.marksObtained,
      grade: mark.grade,
      remarks: mark.remarks || 'Satisfactory progress'
    };
  });

  const aggregateScore = compiledTranscripts.reduce((sum, item) => sum + item.obtained, 0);
  const aggregateMax = compiledTranscripts.reduce((sum, item) => sum + item.maxMarks, 0);
  const cumulativePercentage = aggregateMax > 0 ? Math.round((aggregateScore / aggregateMax) * 100) : 0;

  const handlePrintReport = () => {
    const printContent = printableAreaRef.current?.innerHTML;
    if (!printContent) return;

    // Open clean window for printing
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>AL-irshaad School Report Card - ${selectedStudentObj?.firstName} ${selectedStudentObj?.lastName}</title>
            <style>
              body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 30px; color: #1e293b; background: white; }
              .header { text-align: center; border-bottom: 2px solid #0f172a; pb: 15px; margin-bottom: 25px; }
              .heading { font-size: 24px; font-weight: bold; text-transform: uppercase; margin: 5px 0; }
              .subheading { font-size: 14px; color: #64748b; margin-bottom: 5px; }
              .badge { font-size: 16px; font-weight: 600; color: #000; margin: 10px 0; }
              .grid-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 13px;}
              table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 25px; font-size: 13px; }
              th { background: #0f172a; color: white; padding: 10px; text-align: left; font-weight: 600; }
              td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
              .font-mono { font-family: monospace; font-size: 12px; }
              .footer { margin-top: 50px; display: flex; justify-content: space-between; }
              .sig-block { border-top: 1px solid #94a3b8; width: 220px; text-align: center; font-size: 12px; font-weight: 600; padding-top: 8px; margin-top: 40px; }
              .bold { font-weight: bold; }
              .percentage-card { margin-top: 15px; padding: 10px 15px; background: #f1f5f9; border-radius: 6px; font-weight: bold; display: flex; justify-content: space-between; font-size: 14px; }
            </style>
          </head>
          <body>
            ${printContent}
            <script>
              window.onload = function() { window.print(); window.close(); }
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };


  // Helpers
  function getClassName(classId: string) {
    return classes.find(c => c.id === classId)?.className || '';
  }

  function getSectionName(sectionId: string) {
    return sections.find(s => s.id === sectionId)?.sectionName || '';
  }

  function getSubjectName(subId: string) {
    return subjects.find(s => s.id === subId)?.subjectName || '';
  }

  return (
    <div className="space-y-6">
      {/* Tab bar header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-3 gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">Academic Management</h1>
          <p className="text-sm text-gray-500 mt-1">Record classroom attendance, assess exams, and generate official student transcripts.</p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => { setActiveTab('attendance'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'attendance' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Mark Student Attendance
          </button>
          <button
            onClick={() => { setActiveTab('grading'); setSuccessMsg(''); setMarksEntryList([]); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'grading' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Grade Exam Entries
          </button>
          <button
            onClick={() => { setActiveTab('reportCard'); setSuccessMsg(''); setIsReportGenerated(false); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'reportCard' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Terminal Report Cards
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-xl max-w-4xl mx-auto">
          {successMsg}
        </div>
      )}

      {/* VIEW PANEL ROUTER */}
      {activeTab === 'attendance' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-4 mb-4">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <UserCheck size={16} className="text-slate-900" />
              <span>Mark Student Attendance Register</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Filter by grade and classroom section to fetch the student roster.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-5 items-end">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Grade Level *</label>
              <select
                value={attClassId}
                onChange={(e) => {
                  setAttClassId(e.target.value);
                  const secs = sections.filter(s => s.classId === e.target.value);
                  if (secs.length > 0) setAttSectionId(secs[0].id);
                }}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.className}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Classroom Section *</label>
              <select
                value={attSectionId}
                onChange={(e) => setAttSectionId(e.target.value)}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
              >
                <option value="">Select Section</option>
                {sections
                  .filter(s => s.classId === attClassId)
                  .map(s => (
                    <option key={s.id} value={s.id}>{s.sectionName}</option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Attendance Date</label>
              <input
                type="date"
                value={attDate}
                onChange={(e) => setAttDate(e.target.value)}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white font-mono font-bold"
              />
            </div>

            <div>
              <button
                type="button"
                onClick={handleLoadAttendanceSheet}
                disabled={!attClassId || !attSectionId}
                className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold text-xs py-2 rounded-lg cursor-pointer transition-colors"
              >
                Fetch Student Roster
              </button>
            </div>
          </div>

          {attendanceSheet.length > 0 ? (
            <form onSubmit={handleSaveAttendanceSheet} className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-150 text-xs text-gray-400 uppercase tracking-wider">
                      <th className="py-2.5 px-4 font-semibold">Student ID</th>
                      <th className="py-2.5 px-4 font-semibold">Full Name</th>
                      <th className="py-2.5 px-4 font-semibold">Roll Status</th>
                      <th className="py-2.5 px-4 font-semibold">Exemptions Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-sm">
                    {attendanceSheet.map((record, index) => (
                      <tr key={record.studentId} className="hover:bg-slate-50/50">
                        <td className="py-2 px-4 font-mono text-xs font-semibold text-gray-500">{record.studentId}</td>
                        <td className="py-2 px-4 font-semibold text-gray-900">{record.name}</td>
                        <td className="py-2 px-4">
                          <div className="flex gap-1.5 bg-gray-100 p-0.5 rounded-lg w-fit">
                            {Object.values(AttendanceStatus).map(status => (
                              <button
                                key={status}
                                type="button"
                                onClick={() => handleUpdateRecordStatus(index, status)}
                                className={`px-2 py-1 text-xs rounded transition-all font-semibold cursor-pointer ${
                                  record.status === status 
                                    ? status === AttendanceStatus.PRESENT 
                                      ? 'bg-emerald-500 text-white' 
                                      : status === AttendanceStatus.ABSENT 
                                      ? 'bg-red-500 text-white' 
                                      : status === AttendanceStatus.LATE 
                                      ? 'bg-amber-500 text-white' 
                                      : 'bg-blue-500 text-white'
                                    : 'text-gray-500 hover:text-gray-900'
                                }`}
                              >
                                {status}
                              </button>
                            ))}
                          </div>
                        </td>
                        <td className="py-2 px-4">
                          <input
                            type="text"
                            placeholder="e.g. excused due to illness"
                            value={record.remarks}
                            onChange={(e) => handleUpdateRecordRemarks(index, e.target.value)}
                            className="bg-gray-50 border border-gray-200 px-2 py-1 text-xs rounded focus:outline-hidden text-gray-600 focus:bg-white w-48 focus:ring-1 focus:ring-slate-900"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end pt-4 border-t border-gray-100">
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  Save Daily Student Registry
                </button>
              </div>
            </form>
          ) : (
            <div className="bg-slate-50 border border-dashed border-gray-200 text-gray-400 p-8 rounded-xl text-center flex flex-col items-center justify-center">
              <Calendar size={32} className="text-gray-300 mb-2" />
              <p className="text-xs font-medium">Class Attendance Register Not Loaded</p>
              <p className="text-[11px] text-gray-400 mt-1 max-w-[250px]">Choose the class, section and date then click "Fetch Student Roster" to audit classroom attendance.</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'grading' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-4 mb-4">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Award size={16} className="text-slate-900" />
              <span>Assessment & Exam Marks Entry</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Input term grades and final examination performance metrics for classroom records.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-5 items-end">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Target Grade *</label>
              <select
                value={gradeClassId}
                onChange={(e) => setGradeClassId(e.target.value)}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.className}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Subject *</label>
              <select
                value={gradeSubjectId}
                onChange={(e) => setGradeSubjectId(e.target.value)}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.subjectName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Exam Type *</label>
              <select
                value={gradeExamName}
                onChange={(e) => setGradeExamName(e.target.value)}
                className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
              >
                <option value="Mid-term Exam">Mid-term Exam</option>
                <option value="Final Exam">Final Exam</option>
                <option value="Quiz Assessment">Quiz Assessment</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-semibold text-gray-400 uppercase">Max Points</label>
                <input
                  type="number"
                  value={gradeMaxMarks}
                  onChange={(e) => setGradeMaxMarks(parseInt(e.target.value) || 100)}
                  className="w-full mt-1.5 px-2 py-1.5 text-xs border border-gray-200 rounded-lg bg-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-gray-400 uppercase">Assessment Date</label>
                <input
                  type="date"
                  value={gradeDate}
                  onChange={(e) => setGradeDate(e.target.value)}
                  className="w-full mt-1.5 px-2 py-1.5 text-[10px] border border-gray-200 rounded-lg bg-white font-mono font-semibold"
                />
              </div>
            </div>

            <div>
              <button
                type="button"
                onClick={handleLoadMarksSheet}
                disabled={!gradeClassId || !gradeSubjectId}
                className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold text-xs py-2 rounded-lg cursor-pointer transition-colors"
              >
                Assemble Gradesheet
              </button>
            </div>
          </div>

          {marksEntryList.length > 0 ? (
            <form onSubmit={handleSaveMarksSheet} className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-150 text-xs text-gray-400 uppercase tracking-wider">
                      <th className="py-2.5 px-4 font-semibold">Student ID</th>
                      <th className="py-2.5 px-4 font-semibold">Student Name</th>
                      <th className="py-2.5 px-4 font-semibold">Score Obtained (Max: {gradeMaxMarks})</th>
                      <th className="py-2.5 px-4 font-semibold">Auto Letter Grade</th>
                      <th className="py-2.5 px-4 font-semibold">Remarks / Comments</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-sm">
                    {marksEntryList.map((item, index) => (
                      <tr key={item.studentId} className="hover:bg-slate-50/50">
                        <td className="py-1.5 px-4 font-mono text-xs font-semibold text-gray-500">{item.studentId}</td>
                        <td className="py-1.5 px-4 font-semibold text-gray-900">{item.name}</td>
                        <td className="py-1.5 px-4">
                          <input
                            type="number"
                            min="0"
                            max={gradeMaxMarks}
                            step="0.5"
                            required
                            value={item.marksObtained}
                            onChange={(e) => handleUpdateObtainedMarks(index, e.target.value)}
                            className="bg-gray-50 border border-gray-200 px-3 py-1 text-xs rounded w-24 font-mono font-semibold focus:outline-hidden focus:bg-white focus:ring-1 focus:ring-slate-900"
                          />
                        </td>
                        <td className="py-1.5 px-4">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${
                            item.marksObtained / gradeMaxMarks >= 0.85 
                              ? 'bg-emerald-50 text-emerald-700' 
                              : item.marksObtained / gradeMaxMarks >= 0.62 
                              ? 'bg-blue-50 text-blue-700' 
                              : item.marksObtained / gradeMaxMarks >= 0.4 
                              ? 'bg-amber-50 text-amber-700' 
                              : 'bg-red-50 text-red-600'
                          }`}>
                            {calculateGradeFromMarks(item.marksObtained, gradeMaxMarks)}
                          </span>
                        </td>
                        <td className="py-1.5 px-4">
                          <input
                            type="text"
                            placeholder="Satisfactory performance"
                            value={item.remarks}
                            onChange={(e) => handleUpdateMarksRemarks(index, e.target.value)}
                            className="bg-gray-50 border border-gray-200 px-2.5 py-1 text-xs rounded focus:outline-hidden text-gray-600 focus:bg-white w-48"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end pt-4 border-t border-gray-100">
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  Save Evaluation Marks
                </button>
              </div>
            </form>
          ) : (
            <div className="bg-slate-50 border border-dashed border-gray-200 text-gray-400 p-8 rounded-xl text-center flex flex-col items-center justify-center">
              <Award size={32} className="text-gray-300 mb-2" />
              <p className="text-xs font-medium">Evaluation Sheets Not Assembled</p>
              <p className="text-[11px] text-gray-400 mt-1 max-w-[250px]">Select targeted Grade and subject parameters, then click "Assemble Gradesheet" to enter marks offline.</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'reportCard' && (
        <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-250">
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs">
            <div className="border-b border-gray-50 pb-4 mb-4">
              <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                <FileText size={16} className="text-slate-900" />
                <span>Transcript & Terminal Report Cards</span>
              </h3>
              <p className="text-sm text-gray-400 mt-0.5">Synthesize a comprehensive report transcript with cumulative indices, printing blocks, and attendance summaries.</p>
            </div>

            <div className="flex items-end gap-3 max-w-md">
              <div className="flex-1">
                <label className="block text-xs font-semibold text-gray-400 uppercase">Select Target Student *</label>
                <select
                  value={reportStudentId}
                  onChange={(e) => {
                    setReportStudentId(e.target.value);
                    setIsReportGenerated(false);
                  }}
                  className="w-full mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
                >
                  <option value="">Choose Student</option>
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.middleName} {s.lastName} ({s.id})
                    </option>
                  ))}
                </select>
              </div>
              <button
                onClick={handleGenerateReportCard}
                disabled={!reportStudentId}
                className="bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold text-xs py-2 px-4 rounded-lg transition-colors cursor-pointer"
              >
                Synthesize Report Card
              </button>
            </div>
          </div>

          {isReportGenerated && selectedStudentObj ? (
            <div className="space-y-4 animate-in slide-in-from-bottom-2 duration-300">
              
              {/* Report Actions Preview bar */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex justify-between items-center text-sm">
                <span className="text-xs text-gray-500 font-medium font-sans">Scholarly performance transcript prepared. Frame optimized for standards printing.</span>
                <button
                  type="button"
                  onClick={handlePrintReport}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2 rounded-lg cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Printer size={14} />
                  <span>Request System Print</span>
                </button>
              </div>

              {/* Printable Template Canvas */}
              <div 
                ref={printableAreaRef}
                className="bg-white rounded-xl border border-gray-200 p-8 shadow-xs relative overflow-hidden"
              >
                {/* School Header Title block */}
                <div className="text-center pb-5 mb-5 border-b-2 border-slate-900">
                  <h2 className="text-2xl font-bold tracking-tight uppercase text-slate-900">{schoolSettings.schoolName}</h2>
                  <p className="text-xs text-slate-500 font-medium tracking-wide mt-1 uppercase">AL-IRSHAAD SECONDARY EDUCATION TRANSCRIPT</p>
                  <p className="text-[10px] text-gray-400 mt-1 font-mono">{schoolSettings.address} | Tel: {schoolSettings.phone}</p>
                </div>

                <div className="badge text-center font-bold text-slate-900 uppercase text-sm mb-4">
                  SCHOLASTIC TERMINAL REPORT CARD
                </div>

                {/* Patient Metadata Card Grid */}
                <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 border border-slate-100 p-4 rounded-lg mb-6 leading-relaxed">
                  <div>
                    <p className="text-gray-400 font-medium">STUDENT ID</p>
                    <p className="font-bold text-slate-800 font-mono text-sm mt-0.5">{selectedStudentObj.id}</p>

                    <p className="text-gray-400 font-medium mt-3">STUDENT FULL NAME</p>
                    <p className="font-bold text-slate-900 text-sm mt-0.5">
                      {selectedStudentObj.firstName} {selectedStudentObj.middleName} {selectedStudentObj.lastName}
                    </p>
                  </div>

                  <div>
                    <p className="text-gray-400 font-medium">CLASS ENROLLMENT & ACADEMIC TERM</p>
                    <p className="font-bold text-slate-800 text-sm mt-0.5">
                      {getClassName(selectedStudentObj.classId)} - {getSectionName(selectedStudentObj.sectionId)}
                    </p>

                    <p className="text-gray-400 font-medium mt-3">REPORT ACADEMIC YEAR</p>
                    <p className="font-bold text-slate-800 text-sm mt-0.5">{schoolSettings.academicYear}</p>
                  </div>
                </div>

                {/* Score Listing Table */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase">Exam Score Summary Breakdown</h3>
                  {compiledTranscripts.length === 0 ? (
                    <div className="text-center py-8 text-gray-400 border border-dashed border-gray-200 rounded">
                      No matching exam score registries found for this student.
                    </div>
                  ) : (
                    <table className="w-full text-xs text-left border-collapse border border-slate-200 rounded">
                      <thead>
                        <tr className="bg-slate-900 text-white uppercase text-[10px]">
                          <th className="py-2.5 px-3 border border-slate-250 font-semibold">Subject Matter</th>
                          <th className="py-2.5 px-3 border border-slate-250 font-semibold">Assessment Type</th>
                          <th className="py-2.5 px-3 border border-slate-250 text-center font-semibold">Points Obtained</th>
                          <th className="py-2.5 px-3 border border-slate-250 text-center font-semibold">Maximum Points</th>
                          <th className="py-2.5 px-3 border border-slate-250 text-center font-semibold">Letter Grade</th>
                          <th className="py-2.5 px-3 border border-slate-250 font-semibold">Instructor Comments</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {compiledTranscripts.map((tr) => (
                          <tr key={tr.id}>
                            <td className="py-2 px-3 border border-slate-200 font-bold text-slate-900">{tr.subjectName}</td>
                            <td className="py-2 px-3 border border-slate-200 text-gray-600">{tr.examName}</td>
                            <td className="py-2 px-3 border border-slate-200 text-center font-bold text-slate-800">{tr.obtained}</td>
                            <td className="py-2 px-3 border border-slate-200 text-center font-mono">{tr.maxMarks}</td>
                            <td className="py-2 px-3 border border-slate-200 text-center font-bold text-slate-900">{tr.grade}</td>
                            <td className="py-2 px-3 border border-slate-200 text-gray-500 italic">{tr.remarks}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>

                {/* Summary Totals & Attendance Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  {/* Attendance Audit block */}
                  <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50">
                    <h4 className="text-xs font-bold uppercase text-slate-800 mb-2">Classroom Presence Summary</h4>
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Total School Days Audited:</span>
                        <span className="font-bold">{totalDays} days</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500 font-semibold">Days Logged Present:</span>
                        <span className="font-mono text-emerald-700 font-bold">{presentDays} days</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-200 pt-1.5">
                        <span className="text-gray-750 font-bold">Attendance Ratio:</span>
                        <span className="font-mono font-bold text-slate-900">{attendanceRatePercentage}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Cumulative Score GPA calculation */}
                  <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50 leading-relaxed text-xs">
                    <h4 className="text-xs font-bold uppercase text-slate-800 mb-2 font-sans">Summary Score Totals</h4>
                    <div className="space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Cumulative Raw Score Points:</span>
                        <span className="font-bold">{aggregateScore} / {aggregateMax}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-200 pt-1.5">
                        <span className="text-gray-750 font-bold">Overall Average Percentage:</span>
                        <span className="text-slate-900 font-bold text-sm font-mono">{cumulativePercentage}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500 font-semibold">Term Cumulative Letter Grade:</span>
                        <span className="text-emerald-700 font-extrabold font-mono text-sm">{calculateGradeFromMarks(aggregateScore, aggregateMax)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Faculty Signing Blocks */}
                <div className="mt-12 flex justify-between gap-12 text-center text-xs">
                  <div className="w-[180px] border-t border-slate-900 pt-2 shrink-0">
                    <p className="font-bold text-slate-900 text-[10px]">FACULTY CLASS TEACHER</p>
                    <p className="text-[10px] text-gray-400 mt-1">Signature & Date</p>
                  </div>
                  <div className="w-[180px] pt-1 text-[10px] italic text-slate-400 flex items-center justify-center">
                    Authorized AL-IRSHAAD Registrar Stamp
                  </div>
                  <div className="w-[180px] border-t border-slate-900 pt-2 shrink-0">
                    <p className="font-bold text-slate-900 text-[10px]">PRINCIPAL OF ACADEMICS</p>
                    <p className="text-[10px] text-gray-400 mt-1">Signature & Date</p>
                  </div>
                </div>

              </div>
            </div>
          ) : (
            reportStudentId && (
              <div className="p-6 text-center text-gray-400 bg-slate-50 border border-dashed rounded-xl max-w-4xl mx-auto">
                Select your target student, and click 'Synthesize Report Card' to compile grading structures.
              </div>
            )
          )}
        </div>
      )}

      {activeTab === 'timetable' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-4 mb-4">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Clock size={16} className="text-slate-900" />
              <span>Assigned Period Class Schedules</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Weekly period timetables mapping authorized teachers, subjects, and rooms.</p>
          </div>

          <div className="grid grid-cols-5 gap-3 border border-gray-100 p-4 rounded-xl text-center text-xs">
            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Saturday'].map((day) => (
              <div key={day} className="space-y-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <p className="font-bold text-slate-900 uppercase tracking-wider text-[10px] border-b border-slate-200 pb-1.5">{day}</p>
                
                {day === 'Monday' && (
                  <div className="space-y-2 text-left">
                    <div className="bg-white p-2 rounded-md border border-slate-200 shadow-3xs leading-relaxed text-[11px]">
                      <span className="font-bold text-slate-900 block">Period 1 (07:30-08:15)</span>
                      <span className="text-gray-500 block font-medium">Mathematics - Grade 9</span>
                      <span className="text-slate-400 block text-[10px] font-mono mt-0.5">Teacher: Mahad F. (Room 12)</span>
                    </div>
                    <div className="bg-white p-2 rounded-md border border-slate-200 shadow-3xs leading-relaxed text-[11px]">
                      <span className="font-bold text-slate-900 block">Period 2 (08:15-09:00)</span>
                      <span className="text-gray-500 block font-medium">Physics - Grade 9</span>
                      <span className="text-slate-400 block text-[10px] font-mono mt-0.5">Teacher: Mahad F. (Room 12)</span>
                    </div>
                  </div>
                )}

                {day === 'Tuesday' && (
                  <div className="space-y-2 text-left">
                    <div className="bg-white p-2 rounded-md border border-slate-200 shadow-3xs leading-relaxed text-[11px]">
                      <span className="font-bold text-slate-900 block">Period 1 (07:30-08:15)</span>
                      <span className="text-gray-500 block font-medium">English - Grade 9</span>
                      <span className="text-slate-400 block text-[10px] font-mono mt-0.5">Teacher: Hussein K. (Room 12)</span>
                    </div>
                    <div className="bg-white p-2 rounded-md border border-slate-200 shadow-3xs leading-relaxed text-[11px]">
                      <span className="font-bold text-slate-900 block">Period 2 (08:15-09:00)</span>
                      <span className="text-gray-500 block font-medium">Chemistry - Grade 9</span>
                      <span className="text-slate-400 block text-[10px] font-mono mt-0.5">Teacher: Amina S. (Room 12)</span>
                    </div>
                  </div>
                )}

                {['Wednesday', 'Thursday', 'Saturday'].includes(day) && (
                  <p className="text-[10px] text-gray-400 italic py-4">Standard period scheduling logs assigned.</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
