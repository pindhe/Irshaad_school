import React, { useState, useRef } from 'react';
import { 
  Coins, 
  Search, 
  Plus, 
  X, 
  Check, 
  Printer, 
  CreditCard, 
  DollarSign, 
  FileText, 
  Calculator, 
  TrendingUp, 
  CheckCircle,
  Hash,
  Calendar,
  User,
  ArrowUpRight
} from 'lucide-react';
import { 
  Student, 
  Class, 
  FeeCategory, 
  FeeStructure, 
  Payment, 
  User as UserType,
  UserRole
} from '../types';

interface FinanceModuleProps {
  students: Student[];
  classes: Class[];
  feeCategories: FeeCategory[];
  feeStructures: FeeStructure[];
  payments: Payment[];
  activeUser: UserType;
  onRecordPayment: (payment: Omit<Payment, 'id' | 'receiptNumber'>) => void;
  onAddFeeCategory: (categoryName: string) => void;
  onDeletePayment: (id: string) => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

export default function FinanceModule({
  students,
  classes,
  feeCategories,
  feeStructures,
  payments,
  activeUser,
  onRecordPayment,
  onAddFeeCategory,
  onDeletePayment,
  onLogAction
}: FinanceModuleProps) {
  const [activeTab, setActiveTab] = useState<'collection' | 'dues' | 'categories'>('collection');
  const [searchQuery, setSearchQuery] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // 1. PAYMENT FORM STATE
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [payStudentId, setPayStudentId] = useState('');
  const [payCategoryId, setPayCategoryId] = useState('');
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<'Cash' | 'Bank Transfer' | 'Mobile Money'>('Cash');
  const [payRemarks, setPayRemarks] = useState('');
  const [formError, setFormError] = useState('');

  // 2. RECEIPT VIEWER STATE
  const [selectedReceipt, setSelectedReceipt] = useState<Payment | null>(null);
  const invoicePrinterRef = useRef<HTMLDivElement>(null);

  // Computations
  const getStudentName = (sid: string) => {
    const s = students.find(x => x.id === sid);
    return s ? `${s.firstName} ${s.middleName} ${s.lastName}` : 'Unknown Student';
  };

  const getStudentObj = (sid: string) => students.find(x => x.id === sid);

  const getClassName = (classId: string) => {
    return classes.find(c => c.id === classId)?.className || 'Unknown';
  };

  const getCategoryName = (cid: string) => {
    return feeCategories.find(c => c.id === cid)?.categoryName || 'General Fee';
  };

  // Compute Outstanding Fee Balance for a specific Student
  const computeStudentBalance = (studentId: string) => {
    const s = students.find(x => x.id === studentId);
    if (!s) return { allocated: 0, paid: 0, balance: 0 };

    // Get structures assigned to student's class
    const classStructures = feeStructures.filter(fs => fs.classId === s.classId);
    const totalAllocated = classStructures.reduce((sum, item) => sum + item.amount, 0);

    // Sum matching payments
    const studentPayments = payments.filter(p => p.studentId === studentId);
    const totalPaid = studentPayments.reduce((sum, item) => sum + item.amountPaid, 0);

    return {
      allocated: totalAllocated,
      paid: totalPaid,
      balance: Math.max(0, totalAllocated - totalPaid)
    };
  };

  // Submit Payment Event Handler
  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payStudentId || !payCategoryId || payAmount <= 0) {
      setFormError('Please choose target student, category & enter a positive decimal fee amount.');
      return;
    }

    onRecordPayment({
      studentId: payStudentId,
      categoryId: payCategoryId,
      amountPaid: payAmount,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod: payMethod,
      receivedBy: activeUser.username,
      remarks: payRemarks || undefined
    });

    onLogAction(
      'RECORD_PAYMENT',
      'Payments',
      payStudentId,
      `Recorded payment of USD ${payAmount} for ${getCategoryName(payCategoryId)} from student ${getStudentName(payStudentId)}`
    );

    setSuccessMsg('Fee invoice receipt recorded and tracked safely!');
    setFormError('');
    setIsRecordModalOpen(false);

    // Reset Form
    setPayStudentId('');
    setPayCategoryId('');
    setPayAmount(0);
    setPayRemarks('');
    
    // Auto clear notification
    setTimeout(() => setSuccessMsg(''), 4500);
  };

  // Trigger HTML system print view
  const handlePrintReceipt = (receipt: Payment) => {
    const prntContents = invoicePrinterRef.current?.innerHTML;
    if (!prntContents) return;

    const matchedStud = getStudentObj(receipt.studentId);
    const studentClassVal = matchedStud ? getClassName(matchedStud.classId) : 'N/A';

    const pWindow = window.open('', '_blank');
    if (pWindow) {
      pWindow.document.write(`
        <html>
          <head>
            <title>AL-irshaad Payment Receipt - ${receipt.receiptNumber}</title>
            <style>
              body { font-family: 'Courier New', Courier, monospace; padding: 25px; color: #000; background: white; }
              .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 15px; margin-bottom: 20px; }
              .title { font-size: 18px; font-weight: bold; text-transform: uppercase; }
              .meta-line { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
              .invoice-box { border: 1px solid #000; padding: 15px; border-radius: 4px; margin-top: 15px; background: #fff;}
              .table-section { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
              .table-section th { text-align: left; border-bottom: 1px solid #000; padding: 6px; font-weight: 850; }
              .table-section td { padding: 6px; border-bottom: 1px dashed #efefef; font-size: 13px; }
              .total-block { padding-top: 10px; border-top: 1x solid #000; display: flex; justify-content: space-between; font-weight: bold; font-size: 14px;}
              .sign-line { margin-top: 55px; border-top: 1px dashed #000; max-width: 180px; text-align: center; font-size: 12px; margin-left: auto; margin-right: auto; padding-top: 5px; }
              .sub-heading { text-transform: uppercase; font-size: 10px; letter-spacing: 1px; color:#555;}
            </style>
          </head>
          <body>
            <div class="header">
              <div class="title">AL-IRSHAAD SECONDARY SCHOOL</div>
              <div class="sub-heading">Waberi District, Mogadishu, Somalia</div>
              <div class="sub-heading">Billing and Financial Operations Voucher</div>
            </div>

            <div class="meta-line"><span class="bold">RECEIPT ID:</span> <span class="bold">${receipt.receiptNumber}</span></div>
            <div class="meta-line"><span>DATE PRINTED:</span> <span>${receipt.paymentDate}</span></div>
            <div class="meta-line"><span>CLIENT STUDENT:</span> <span>${getStudentName(receipt.studentId)}</span></div>
            <div class="meta-line"><span>GRADE & TERM:</span> <span>${studentClassVal}</span></div>

            <table class="table-section">
              <thead>
                <tr>
                  <th>FEE DESIGNATION</th>
                  <th>PAY METHOD</th>
                  <th style="text-align: right;">AMOUNT PAID</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>${getCategoryName(receipt.categoryId)}</td>
                  <td>${receipt.paymentMethod}</td>
                  <td style="text-align: right;">USD ${receipt.amountPaid.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>

            <div class="total-block">
              <span>REMAINING GRADE BALANCES:</span>
              <span>USD ${computeStudentBalance(receipt.studentId).balance.toFixed(2)}</span>
            </div>

            <div class="meta-line" style="margin-top: 15px; font-size: 11px;">
              <span>RECEIVED BY CLERK:</span>
              <span>${receipt.receivedBy} (System Log Record)</span>
            </div>

            <div class="sign-line">AL-IRSHAAD BILLING DEPARTMENT</div>
            <script>
              window.onload = function() { window.print(); window.close(); }
            </script>
          </body>
        </html>
      `);
      pWindow.document.close();
    }
  };

  // Add category state
  const [newCatName, setNewCatName] = useState('');
  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName) return;
    onAddFeeCategory(newCatName);
    onLogAction(
      'CREATE_FEE_CATEGORY',
      'FeeCategories',
      'NEW',
      `Registered a new fee categorization segment identified as: ${newCatName}`
    );
    setNewCatName('');
    setSuccessMsg('New fee asset classification assigned successfully!');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  // Filter payments
  const filteredPayments = payments.filter(p => {
    const sName = getStudentName(p.studentId).toLowerCase();
    const isMatched = sName.includes(searchQuery.toLowerCase()) || 
                      p.receiptNumber.toLowerCase().includes(searchQuery.toLowerCase());
    return isMatched;
  });

  return (
    <div className="space-y-6">
      {/* Tab bar header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-3 gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">Fee & Finance Operations</h1>
          <p className="text-sm text-gray-500 mt-1">Audit school cash accounts, register term structures, and publish transaction receipts.</p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => { setActiveTab('collection'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'collection' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Payments Catalog
          </button>
          <button
            onClick={() => { setActiveTab('dues'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'dues' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Outstanding Dues Ledger
          </button>
          <button
            onClick={() => { setActiveTab('categories'); setSuccessMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'categories' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Fee Asset Settings
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-xl max-w-4xl mx-auto">
          {successMsg}
        </div>
      )}

      {/* VIEW TABS ROUTER */}
      {activeTab === 'collection' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-250">
          
          {/* Column list of invoices */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow shadow-gray-50 space-y-4">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="relative w-full max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={17} />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by receipt voucher number or student..."
                    className="w-full pl-9 pr-4 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden text-gray-700 font-sans focus:bg-white focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  <span>Receive Cash Payment</span>
                </button>
              </div>

              {/* Transactions list */}
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-100 text-[#94a3b8] text-[10px] uppercase font-bold tracking-wider">
                      <th className="py-2 px-3">VJ-Voucher ID</th>
                      <th className="py-2 px-3">Student Name</th>
                      <th className="py-2 px-3">Classification</th>
                      <th className="py-2 px-3">Date</th>
                      <th className="py-2 px-3">Channel</th>
                      <th className="py-2 px-3 text-right">Sum (USD)</th>
                      <th className="py-2 px-3 text-right">Voucher</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-xs">
                    {filteredPayments.map(pay => (
                      <tr 
                        key={pay.id}
                        onClick={() => setSelectedReceipt(pay)}
                        className={`hover:bg-slate-50/50 cursor-pointer transition-colors ${selectedReceipt?.id === pay.id ? 'bg-slate-50' : ''}`}
                      >
                        <td className="py-3 px-3 font-mono font-bold text-slate-800">{pay.receiptNumber}</td>
                        <td className="py-3 px-3">
                          <p className="font-semibold text-gray-900">{getStudentName(pay.studentId)}</p>
                          <p className="text-[10px] text-gray-400 font-mono mt-0.5">{pay.studentId}</p>
                        </td>
                        <td className="py-3 px-3 font-medium text-gray-650">{getCategoryName(pay.categoryId)}</td>
                        <td className="py-3 px-3 text-gray-400 font-mono font-medium">{pay.paymentDate}</td>
                        <td className="py-3 px-3">
                          <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-bold uppercase">{pay.paymentMethod}</span>
                        </td>
                        <td className="py-3 px-3 text-right font-bold text-slate-900 font-mono">USD {pay.amountPaid.toFixed(2)}</td>
                        <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => handlePrintReceipt(pay)}
                            className="bg-gray-100 hover:bg-gray-200 text-slate-900 p-1.5 rounded transition-all cursor-pointer inline-flex items-center gap-1 text-[10px] font-bold"
                          >
                            <Printer size={12} />
                            <span>Slip</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Column voucher receipt preview card */}
          <div className="lg:col-span-1">
            {selectedReceipt ? (
              <div className="bg-white rounded-xl border border-gray-100 p-5 shadow sticky top-6 space-y-4">
                <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                  <div className="flex items-center gap-2">
                    <InvoiceIcon />
                    <div>
                      <h4 className="font-semibold text-gray-800 text-sm">Receipt Voucher</h4>
                      <p className="font-mono text-xs text-gray-400 mt-0.5">{selectedReceipt.receiptNumber}</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedReceipt(null)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                    <X size={16} />
                  </button>
                </div>

                {/* Simulated print frame content preview */}
                <div 
                  ref={invoicePrinterRef} 
                  className="bg-slate-50 rounded-lg p-4 font-mono text-[11px] leading-relaxed border border-slate-100 text-slate-800 space-y-2.5 shadow-3xs"
                >
                  <p className="font-bold text-slate-950 uppercase border-b border-dashed border-slate-200 pb-1.5 text-center mb-1">
                    AL-IRSHAAD SECO SCHOOL BILLING SLIP
                  </p>
                  <div>
                    <span className="text-gray-400 font-medium">Receipt ID:</span>
                    <p className="font-bold text-slate-900">{selectedReceipt.receiptNumber}</p>
                  </div>
                  <div>
                    <span className="text-gray-400 font-medium">Student Client:</span>
                    <p className="font-bold text-slate-900">{getStudentName(selectedReceipt.studentId)}</p>
                  </div>
                  <div>
                    <span className="text-gray-400 font-medium">Voucher Segment:</span>
                    <p className="font-bold text-slate-900">{getCategoryName(selectedReceipt.categoryId)}</p>
                  </div>
                  <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 font-bold text-slate-950 text-xs">
                    <span>Sum Collected:</span>
                    <span>USD {selectedReceipt.amountPaid.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span className="text-gray-400">Payment Channel:</span>
                    <span>{selectedReceipt.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 text-[10px]">
                    <span>Remaining Debits:</span>
                    <span className="font-bold text-slate-900">USD {computeStudentBalance(selectedReceipt.studentId).balance.toFixed(2)}</span>
                  </div>
                  {selectedReceipt.remarks && (
                    <div className="pt-1.5 text-[10px] text-gray-400 italic">
                      Notes: {selectedReceipt.remarks}
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handlePrintReceipt(selectedReceipt)}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2 rounded-lg transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5"
                >
                  <Printer size={13} />
                  <span>Send to Desktop Printer</span>
                </button>

                {/* Deletion Control with RBAC Checks */}
                <div className="border-t border-slate-100 pt-3 mt-1">
                  <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-2 leading-none">Record Deletion (RBAC Enforcement)</span>
                  {activeUser.role === UserRole.ADMIN_LIMITED ? (
                    <div className="bg-amber-50 border border-amber-100 rounded-lg p-2.5">
                      <p className="text-[10px] text-amber-800 font-medium leading-relaxed font-sans">
                        ⚠️ Your role <strong>{activeUser.role}</strong> only allows <strong>Add / Update</strong> access. Only <strong>Administrator</strong> can delete records parsing ledger transactions.
                      </p>
                      <button
                        type="button"
                        disabled
                        className="w-full mt-2 bg-slate-100 text-slate-400 border border-slate-200 text-xs font-semibold py-2 rounded-lg cursor-not-allowed flex items-center justify-center gap-1.5"
                      >
                        Delete Receipt Voucher (Locked)
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`Are you absolutely sure you want to permanently delete receipt record ${selectedReceipt.receiptNumber} totaling USD ${selectedReceipt.amountPaid}? This action will adjust the outstanding dues.`)) {
                          onDeletePayment(selectedReceipt.id);
                          onLogAction('FEE_PAYMENT_DELETION', 'Payments', selectedReceipt.id, `Permanently deleted payment receipt record ${selectedReceipt.receiptNumber} of USD ${selectedReceipt.amountPaid}`);
                          setSelectedReceipt(null);
                        }
                      }}
                      className="w-full bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 text-xs font-semibold py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 font-sans"
                    >
                      Delete Receipt Voucher
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 border border-dashed border-gray-200 text-gray-400 p-8 rounded-xl text-center py-10 flex flex-col items-center justify-center">
                <Coins size={32} className="text-slate-350 mb-2" />
                <h4 className="text-sm font-semibold">Invoice Voucher Preview</h4>
                <p className="text-xs text-gray-400 mt-1 max-w-[200px]">Click any transaction item log inside the ledger catalog to inspect, print, or compile receipts.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'dues' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-4 mb-4">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Calculator size={16} className="text-slate-900" />
              <span>Outstanding Dues Balance Ledger</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Summary of assigned academic fees, collected totals, and remaining outstanding balances.</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-gray-150 text-[10px] text-[#94a3b8] font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Student ID</th>
                  <th className="py-2.5 px-3">Enrolled Pupil</th>
                  <th className="py-2.5 px-3">Enrolled Grade</th>
                  <th className="py-2.5 px-3 text-right">Sum Debited (USD)</th>
                  <th className="py-2.5 px-3 text-right">Sum Paid (USD)</th>
                  <th className="py-2.5 px-3 text-right">Remaining Balance (USD)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-xs">
                {students.map(student => {
                  const { allocated, paid, balance } = computeStudentBalance(student.id);
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-mono text-gray-400 font-bold">{student.id}</td>
                      <td className="py-2 px-3 font-semibold text-slate-900">{student.firstName} {student.middleName} {student.lastName}</td>
                      <td className="py-2 px-3 font-medium text-gray-600">{getClassName(student.classId)}</td>
                      <td className="py-2 px-3 text-right font-mono font-medium">USD {allocated.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono text-emerald-700 font-semibold font-medium">USD {paid.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono font-extrabold text-red-500">
                        {balance === 0 ? (
                          <span className="text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded text-[10.5px] font-bold font-sans">Settle Full</span>
                        ) : (
                          `USD ${balance.toFixed(2)}`
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'categories' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto animate-in fade-in duration-250">
          
          {/* List existing Asset Categories */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs">
            <h3 className="font-semibold text-gray-800 border-b border-gray-50 pb-3 mb-3 text-sm flex items-center gap-2">
              <Coins size={15} />
              <span>Registered Fee Assets Classification</span>
            </h3>

            <div className="space-y-2">
              {feeCategories.map(cat => (
                <div key={cat.id} className="p-3 bg-slate-50 rounded-lg flex items-center justify-between text-xs font-semibold text-slate-800 border border-slate-100">
                  <span>{cat.categoryName}</span>
                  <span className="text-[10px] text-gray-400 font-mono">{cat.id}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Form to Append Category */}
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <h3 className="font-semibold text-gray-800 border-b border-gray-50 pb-3 mb-3 text-sm">
              Register New Fee segment
            </h3>

            <form onSubmit={handleAddCategorySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase">Fee Asset Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Science Laboratory Fee"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full mt-2 px-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-hidden bg-white focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-4 py-2 rounded-lg cursor-pointer transition-colors"
                >
                  Save Fee Segment
                </button>
              </div>
            </form>
          </div>

        </div>
      )}

      {/* PAYMENT TRANSACTION DIALOG ENTRY */}
      {isRecordModalOpen && (
        <div className="fixed inset-0 bg-black/45 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-gray-100 w-full max-w-md overflow-hidden animate-in fade-in duration-150">
            <div className="bg-slate-50 border-b border-gray-150 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Coins size={16} className="text-slate-800" />
                <h3 className="font-semibold text-gray-900 text-sm">Receive Student Fee Cash Asset</h3>
              </div>
              <button onClick={() => setIsRecordModalOpen(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="p-5 space-y-4">
              {formError && (
                <div className="p-2.5 bg-red-50 border border-red-100 rounded text-red-600 text-xs font-semibold">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Enrolled Student *</label>
                <select
                  required
                  value={payStudentId}
                  onChange={(e) => setPayStudentId(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg bg-white"
                >
                  <option value="">Select Student</option>
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.middleName} {s.lastName} ({s.id})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Category *</label>
                  <select
                    required
                    value={payCategoryId}
                    onChange={(e) => setPayCategoryId(e.target.value)}
                    className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg bg-white"
                  >
                    <option value="">Select Segment</option>
                    {feeCategories.map(c => (
                      <option key={c.id} value={c.id}>{c.categoryName}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Payment Channel *</label>
                  <select
                    required
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value as any)}
                    className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg bg-white"
                  >
                    <option value="Cash">Cash (Hand-over)</option>
                    <option value="Bank Transfer">Bank Transfer (Somali Bank)</option>
                    <option value="Mobile Money">Mobile Money (EVC Plus)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Sum Paid (USD) *</label>
                <div className="relative mt-1.5">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold font-mono text-xs">USD</span>
                  <input
                    type="number"
                    min="1"
                    step="0.5"
                    required
                    placeholder="e.g. 400.00"
                    value={payAmount || ''}
                    onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                    className="w-full pl-12 pr-4 py-2 text-xs border border-gray-200 rounded-lg bg-white font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Transaction memo / Remarks</label>
                <textarea
                  placeholder="Notes (e.g. deposited somali bank or evc serial notes)"
                  value={payRemarks}
                  rows={2}
                  onChange={(e) => setPayRemarks(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(false)}
                  className="px-4 py-1.5 text-xs text-gray-500 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer font-bold"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded-md cursor-pointer font-extrabold"
                >
                  Approve Collection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

// Aesthetic Sub-utility component
function InvoiceIcon() {
  return (
    <div className="w-10 h-10 bg-slate-900 text-white flex items-center justify-center rounded-xl font-bold">
      <FileText size={18} />
    </div>
  );
}
