import React, { useState } from 'react';
import { 
  Search, 
  UserPlus, 
  Plus, 
  GraduationCap, 
  X, 
  Check, 
  Info, 
  Calendar, 
  Phone, 
  Mail, 
  MapPin, 
  ChevronRight, 
  BookOpen, 
  FileText, 
  ArrowUpRight 
} from 'lucide-react';
import { Student, Class, Section, User, UserRole } from '../types';

interface StudentModuleProps {
  students: Student[];
  classes: Class[];
  sections: Section[];
  activeUser: User;
  onAddStudent: (student: Omit<Student, 'id' | 'admissionDate' | 'isActive'>) => void;
  onUpdateStudent: (student: Student) => void;
  onPromoteStudent: (studentId: string, newClassId: string, newSectionId: string) => void;
  onDeleteStudent: (id: string) => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

export default function StudentModule({
  students,
  classes,
  sections,
  activeUser,
  onAddStudent,
  onUpdateStudent,
  onPromoteStudent,
  onDeleteStudent,
  onLogAction
}: StudentModuleProps) {
  // Navigation & View states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('ALL');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isAdmissionModalOpen, setIsAdmissionModalOpen] = useState(false);
  const [isPromoteModalOpen, setIsPromoteModalOpen] = useState(false);
  
  // Promotion States
  const [promoteClassId, setPromoteClassId] = useState('');
  const [promoteSectionId, setPromoteSectionId] = useState('');

  // Form states for Admission
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Mogadishu');
  const [parentName, setParentName] = useState('');
  const [parentContact, setParentContact] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [formClassId, setFormClassId] = useState('');
  const [formSectionId, setFormSectionId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Filtering Logic
  const filteredStudents = students.filter(student => {
    const fullName = `${student.firstName} ${student.middleName} ${student.lastName}`.toLowerCase();
    const matchesSearch = 
      fullName.includes(searchQuery.toLowerCase()) || 
      student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.parentName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClassId === 'ALL' || student.classId === selectedClassId;
    const matchesSection = selectedSectionId === 'ALL' || student.sectionId === selectedSectionId;
    
    return matchesSearch && matchesClass && matchesSection;
  });

  const getClassName = (classId: string) => {
    return classes.find(c => c.id === classId)?.className || 'Unknown';
  };

  const getSectionName = (sectionId: string) => {
    return sections.find(s => s.id === sectionId)?.sectionName || 'Unknown';
  };

  // Submit Admission
  const handleSubmitAdmission = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !dateOfBirth || !parentName || !parentContact || !formClassId || !formSectionId) {
      setErrorMsg('Please fill in all mandatory fields.');
      return;
    }

    onAddStudent({
      firstName,
      middleName,
      lastName,
      dateOfBirth,
      gender,
      address,
      city,
      parentName,
      parentContact,
      parentEmail,
      classId: formClassId,
      sectionId: formSectionId
    });

    // Reset Form
    setFirstName('');
    setMiddleName('');
    setLastName('');
    setDateOfBirth('');
    setGender('Male');
    setAddress('');
    setParentName('');
    setParentContact('');
    setParentEmail('');
    setFormClassId('');
    setFormSectionId('');
    setErrorMsg('');
    setIsAdmissionModalOpen(false);
  };

  const handlePromoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !promoteClassId || !promoteSectionId) return;

    onPromoteStudent(selectedStudent.id, promoteClassId, promoteSectionId);
    
    // Log the promotion
    onLogAction(
      'STUDENT_PROMOTION',
      'Students',
      selectedStudent.id,
      `Promoted student ${selectedStudent.firstName} ${selectedStudent.lastName} to ${getClassName(promoteClassId)} - ${getSectionName(promoteSectionId)}`
    );

    // Update selected student profile view state
    setSelectedStudent(prev => prev ? { ...prev, classId: promoteClassId, sectionId: promoteSectionId } : null);
    setIsPromoteModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-gray-100 pb-5">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">Student Management</h1>
          <p className="text-sm text-gray-500 mt-1">Configure student admissions, sections allocation, and track profiles.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAdmissionModalOpen(true)}
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium px-4 py-2.5 rounded-lg transition-colors cursor-pointer"
          >
            <UserPlus size={16} />
            <span>New Admission</span>
          </button>
        </div>
      </div>

      {/* Main Layout containing either List view or Split Profile view */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left/Middle Column: Filter and Student Table List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-gray-100 p-4 space-y-4 shadow-xs">
            {/* Search and Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search by ID, Name or Parent..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
                />
              </div>
              <div>
                <select
                  value={selectedClassId}
                  onChange={(e) => setSelectedClassId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white"
                >
                  <option value="ALL">All Grades</option>
                  {classes.map(cls => (
                    <option key={cls.id} value={cls.id}>{cls.className}</option>
                  ))}
                </select>
              </div>
              <div>
                <select
                  value={selectedSectionId}
                  onChange={(e) => setSelectedSectionId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:bg-white"
                >
                  <option value="ALL">All Sections</option>
                  {sections
                    .filter(sec => selectedClassId === 'ALL' || sec.classId === selectedClassId)
                    .map(sec => (
                      <option key={sec.id} value={sec.id}>{sec.sectionName}</option>
                    ))}
                </select>
              </div>
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto min-h-[350px]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider">
                    <th className="py-3 px-4 font-medium">Student ID</th>
                    <th className="py-3 px-4 font-medium">Name</th>
                    <th className="py-3 px-4 font-medium">Class / Section</th>
                    <th className="py-3 px-4 font-medium">Parent Contact</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 text-right font-medium">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 text-sm">
                  {filteredStudents.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-10 text-center text-gray-400">
                        No students found matching your criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredStudents.map(student => (
                      <tr 
                        key={student.id}
                        className={`hover:bg-slate-50/50 transition-colors duration-150 cursor-pointer ${selectedStudent?.id === student.id ? 'bg-slate-50' : ''}`}
                        onClick={() => setSelectedStudent(student)}
                      >
                        <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-700">{student.id}</td>
                        <td className="py-3 px-4 font-medium text-gray-900">
                          {student.firstName} {student.middleName} {student.lastName}
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {getClassName(student.classId)} - <span className="text-gray-400 text-xs font-medium">{getSectionName(student.sectionId)}</span>
                        </td>
                        <td className="py-3 px-4 text-gray-500 text-xs">{student.parentName} ({student.parentContact})</td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${
                            student.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'
                          }`}>
                            <span className={`h-1.5 w-1.5 rounded-full ${student.isActive ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                            {student.isActive ? 'Enrolled' : 'Inactive'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => setSelectedStudent(student)}
                            className="text-xs text-slate-700 hover:text-slate-900 bg-gray-100 hover:bg-gray-200 px-2.5 py-1.5 rounded-md font-medium transition-colors cursor-pointer inline-flex items-center gap-1"
                          >
                            <span>Profile</span>
                            <ChevronRight size={12} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Total Indicator */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-50 text-xs text-gray-400">
              <p>Showing {filteredStudents.length} of {students.length} students</p>
              <p>System context: Mogadishu Local Time</p>
            </div>
          </div>
        </div>

        {/* Right Column: Profile Detailed View */}
        <div className="lg:col-span-1">
          {selectedStudent ? (
            <div className="bg-white rounded-xl border border-gray-100 shadow-xs divide-y divide-gray-100 overflow-hidden sticky top-6">
              {/* Profile Card Header */}
              <div className="p-5 bg-slate-50/50 flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-lg">
                    {selectedStudent.firstName[0]}{selectedStudent.lastName[0]}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {selectedStudent.firstName} {selectedStudent.lastName}
                    </h3>
                    <p className="text-xs text-gray-500 font-mono mt-0.5">{selectedStudent.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedStudent(null)}
                  className="p-1 text-gray-400 hover:text-gray-600 rounded-md hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Profile Information Block */}
              <div className="p-5 space-y-4 text-sm">
                <div className="flex justify-between items-center text-xs text-gray-400 font-semibold uppercase tracking-wider">
                  <span>Class Information</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg">
                  <div>
                    <p className="text-gray-400 font-medium">Grade</p>
                    <p className="font-semibold text-gray-800 text-sm mt-0.5">{getClassName(selectedStudent.classId)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 font-medium">Section</p>
                    <p className="font-semibold text-gray-800 text-sm mt-0.5">{getSectionName(selectedStudent.sectionId)}</p>
                  </div>
                </div>

                <div className="space-y-2.5 pt-2">
                  <div className="flex items-start gap-2.5 text-gray-600">
                    <Calendar size={15} className="mt-0.5 text-gray-400 shrink-0" />
                    <div>
                      <p className="text-xs text-gray-400 font-mono">Date of Birth / Gender</p>
                      <p className="text-gray-800 text-xs mt-0.5">{selectedStudent.dateOfBirth} ({selectedStudent.gender})</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5 text-gray-600">
                    <MapPin size={15} className="mt-0.5 text-gray-400 shrink-0" />
                    <div>
                      <p className="text-xs text-gray-400 font-mono">Address</p>
                      <p className="text-gray-800 text-xs mt-0.5">{selectedStudent.address}, {selectedStudent.city}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Parent/Guardian Info */}
              <div className="p-5 space-y-3 font-sans">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400">Parent / Guardian</h4>
                <div className="bg-slate-50/50 border border-slate-100 p-3 rounded-lg space-y-2">
                  <p className="font-medium text-gray-800 text-sm">{selectedStudent.parentName}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Phone size={13} />
                    <span>{selectedStudent.parentContact}</span>
                  </div>
                  {selectedStudent.parentEmail && (
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Mail size={13} />
                      <span>{selectedStudent.parentEmail}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Admission Info & Action triggers */}
              <div className="p-5 space-y-4">
                <div className="flex justify-between items-center text-xs text-gray-500">
                  <span>Enrolled Since:</span>
                  <span className="font-semibold text-gray-700">{selectedStudent.admissionDate}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPromoteModalOpen(true)}
                    className="flex-1 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium py-2 rounded-lg transition-colors cursor-pointer text-center inline-flex items-center justify-center gap-1.5"
                  >
                    <GraduationCap size={14} />
                    <span>Promote Student</span>
                  </button>
                  <button
                    onClick={() => {
                      const updated = { ...selectedStudent, isActive: !selectedStudent.isActive };
                      onUpdateStudent(updated);
                      setSelectedStudent(updated);
                      onLogAction(
                        'STUDENT_STATUS_UPDATE',
                        'Students',
                        selectedStudent.id,
                        `Updated student enrollment state of ${selectedStudent.firstName} to ${updated.isActive ? 'Active' : 'Inactive'}`
                      );
                    }}
                    className={`px-3 py-2 rounded-lg text-xs font-medium cursor-pointer transition-colors border ${
                      selectedStudent.isActive 
                        ? 'bg-red-50 hover:bg-red-100 text-red-600 border-red-100' 
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border-emerald-100'
                    }`}
                  >
                    {selectedStudent.isActive ? 'Suspend' : 'Reactivate'}
                  </button>
                </div>

                {/* Deletion Control with RBAC Checks */}
                <div className="border-t border-slate-100 pt-4 mt-2">
                  <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-2 leading-none">Record Deletion (RBAC Enforcement)</span>
                  {activeUser.role === UserRole.ADMIN_LIMITED ? (
                    <div className="bg-amber-50 border border-amber-100 rounded-lg p-3">
                      <p className="text-[11px] text-amber-800 font-medium leading-relaxed">
                        ⚠️ Your role <strong>{activeUser.role}</strong> only allows <strong>Add / Update</strong> access. Only <strong>Administrator</strong> can delete records.
                      </p>
                      <button
                        type="button"
                        disabled
                        className="w-full mt-2 bg-slate-100 text-slate-400 border border-slate-200 text-xs font-semibold py-2 rounded-lg cursor-not-allowed flex items-center justify-center gap-1.5"
                      >
                        Delete Student Record (Locked)
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`Are you absolutely sure you want to permanently delete student profile ${selectedStudent.firstName} ${selectedStudent.lastName}? This action cannot be undone.`)) {
                          onDeleteStudent(selectedStudent.id);
                          onLogAction('STUDENT_DELETION', 'Students', selectedStudent.id, `Permanently deleted student record: ${selectedStudent.firstName} ${selectedStudent.lastName}`);
                          setSelectedStudent(null);
                        }
                      }}
                      className="w-full bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 text-xs font-semibold py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      Delete Student Record
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-gray-200 rounded-xl p-8 text-center text-gray-400 flex flex-col items-center justify-center h-72">
              <Info size={36} className="text-gray-300 mb-3" />
              <p className="text-sm font-medium">No Student Selected</p>
              <p className="text-xs text-gray-400 mt-1 max-w-[200px] mx-auto">Click on any row in the list to inspect profiles, process promotions, or suspend accounts.</p>
            </div>
          )}
        </div>
      </div>

      {/* ADMISSION DIALOG MODAL */}
      {isAdmissionModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-gray-100 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="bg-slate-50 border-b border-gray-100 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserPlus className="text-slate-900" size={18} />
                <h3 className="font-semibold text-gray-900">Student Admission Entry</h3>
              </div>
              <button 
                onClick={() => setIsAdmissionModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-150 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmitAdmission} className="p-6 space-y-4">
              {errorMsg && (
                <div className="p-3 bg-red-50 border border-red-100 rounded-lg text-red-600 text-xs font-semibold">
                  {errorMsg}
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">First Name *</label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. Hassan"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Middle Name</label>
                  <input
                    type="text"
                    value={middleName}
                    onChange={(e) => setMiddleName(e.target.value)}
                    placeholder="e.g. Elmi"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Nur"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Date of Birth *</label>
                  <input
                    type="text"
                    required
                    placeholder="dd-mm-yyyy"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Gender *</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as 'Male' | 'Female')}
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-955"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Admission Grade *</label>
                  <select
                    required
                    value={formClassId}
                    onChange={(e) => {
                      setFormClassId(e.target.value);
                      // Default first section
                      const matchedSecs = sections.filter(s => s.classId === e.target.value);
                      if (matchedSecs.length > 0) {
                        setFormSectionId(matchedSecs[0].id);
                      }
                    }}
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-955"
                  >
                    <option value="">Select Class</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.className}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Class Section *</label>
                  <select
                    required
                    value={formSectionId}
                    onChange={(e) => setFormSectionId(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-955"
                  >
                    <option value="">Select Section</option>
                    {sections
                      .filter(s => s.classId === formClassId)
                      .map(s => (
                        <option key={s.id} value={s.id}>{s.sectionName}</option>
                      ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">City Location</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Mogadishu"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Residential Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Waberi District, Section 3"
                  className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-955"
                />
              </div>

              <div className="border-t border-gray-100 pt-3 text-xs text-gray-400 font-semibold uppercase tracking-wider">
                Parent / Guardian Information
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Parent Full Name *</label>
                  <input
                    type="text"
                    required
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    placeholder="e.g. Elmi Nur Farah"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Parent Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={parentContact}
                    onChange={(e) => setParentContact(e.target.value)}
                    placeholder="e.g. +252 61..."
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Parent Email</label>
                  <input
                    type="email"
                    value={parentEmail}
                    onChange={(e) => setParentEmail(e.target.value)}
                    placeholder="e.g. parent@example.com"
                    className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950"
                  />
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-2 border-t border-gray-150 pt-5">
                <button
                  type="button"
                  onClick={() => setIsAdmissionModalOpen(false)}
                  className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition-colors cursor-pointer font-semibold inline-flex items-center gap-1.5"
                >
                  <Plus size={16} />
                  <span>Register & Enroll</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PROMOTION DIALOG MODAL */}
      {isPromoteModalOpen && selectedStudent && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-gray-100 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-slate-50 border-b border-gray-100 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GraduationCap className="text-slate-900" size={18} />
                <h3 className="font-semibold text-gray-900 text-sm">Promote/Transfer Academic Record</h3>
              </div>
              <button onClick={() => setIsPromoteModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handlePromoteSubmit} className="p-5 space-y-4">
              <div className="text-sm text-gray-600">
                You are changing the enrolled class configuration of student <strong className="text-slate-900">{selectedStudent.firstName} {selectedStudent.lastName}</strong>.
              </div>
              <div className="text-xs text-gray-400 bg-gray-50 border border-gray-100 p-2.5 rounded-md">
                Current Class: <span className="font-semibold text-gray-700">{getClassName(selectedStudent.classId)} - {getSectionName(selectedStudent.sectionId)}</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Target Promotion Grade *</label>
                <select
                  required
                  value={promoteClassId}
                  onChange={(e) => {
                    setPromoteClassId(e.target.value);
                    const matchedSecs = sections.filter(s => s.classId === e.target.value);
                    if (matchedSecs.length > 0) {
                      setPromoteSectionId(matchedSecs[0].id);
                    }
                  }}
                  className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950 bg-white"
                >
                  <option value="">Select Grade</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>{c.className}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Target Section *</label>
                <select
                  required
                  value={promoteSectionId}
                  onChange={(e) => setPromoteSectionId(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-950 bg-white"
                >
                  <option value="">Select Section</option>
                  {sections
                    .filter(s => s.classId === promoteClassId)
                    .map(s => (
                      <option key={s.id} value={s.id}>{s.sectionName}</option>
                    ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                <button
                  type="button"
                  onClick={() => setIsPromoteModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-gray-500 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors cursor-pointer"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded-md transition-colors cursor-pointer font-semibold"
                >
                  Confirm Promotion
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
