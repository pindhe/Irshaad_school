import React, { useState, useRef } from 'react';
import { 
  Database, 
  Settings, 
  Activity, 
  Download, 
  Upload, 
  Check, 
  X, 
  CheckCircle, 
  AlertTriangle, 
  Calendar, 
  Phone, 
  Mail, 
  MapPin, 
  Trash2 
} from 'lucide-react';
import { SchoolSettings, AuditLog, User, UserRole } from '../types';

interface SettingsModuleProps {
  schoolSettings: SchoolSettings;
  auditLogs: AuditLog[];
  activeUser: User;
  onUpdateSettings: (settings: SchoolSettings) => void;
  onBackupDatabase: () => void;
  onRestoreDatabase: (dbState: any) => boolean;
  onResetDatabaseToDefault: () => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

export default function SettingsModule({
  schoolSettings,
  auditLogs,
  activeUser,
  onUpdateSettings,
  onBackupDatabase,
  onRestoreDatabase,
  onResetDatabaseToDefault,
  onLogAction
}: SettingsModuleProps) {
  const [activeTab, setActiveTab] = useState<'profile' | 'backup' | 'audit'>('profile');
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 1. GENERAL SETTINGS STATE
  const [schoolName, setSchoolName] = useState(schoolSettings.schoolName);
  const [academicYear, setAcademicYear] = useState(schoolSettings.academicYear);
  const [address, setAddress] = useState(schoolSettings.address);
  const [phone, setPhone] = useState(schoolSettings.phone);
  const [email, setEmail] = useState(schoolSettings.email);

  const handleUpdateGeneralSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      ...schoolSettings,
      schoolName,
      academicYear,
      address,
      phone,
      email
    });
    setSuccessMsg('School administrative context updated successfully!');
    onLogAction(
      'UPDATE_SCHOOL_SETTINGS',
      'Settings',
      'SCHOOL_METADATA',
      `Updated school general properties: ${schoolName}, Term: ${academicYear}`
    );
    setTimeout(() => setSuccessMsg(''), 4500);
  };

  // 2. BACKUP & RESTORE EVENT HANDLERS
  const handleUploadBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const textStr = event.target?.result as string;
        const parsedState = JSON.parse(textStr);
        
        // Assert schema verification keys to guarantee file sanity prior to loading
        const requiredKeys = ['students', 'staffList', 'books', 'payments', 'schoolSettings'];
        const matches = requiredKeys.every(k => k in parsedState);
        
        if (!matches) {
          setErrorMsg('Uploaded file schema is invalid or does not correspond to AL-irshaad database exports.');
          return;
        }

        const success = onRestoreDatabase(parsedState);
        if (success) {
          setSuccessMsg('AL-irshaad School offline database restored successfully! Repopulated all rosters.');
          setErrorMsg('');
          onLogAction(
            'RESTORE_DATABASE',
            'Database',
            'ALL',
            `Successfully restored database from offline file: ${file.name}`
          );
        } else {
          setErrorMsg('Error rebuilding tables from backup.');
        }
      } catch (err) {
        setErrorMsg('Error reading selected backup. Verify JSON encoding properties.');
      }
    };
    reader.readAsText(file);
    // Reset file input value
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Sub-Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-3 gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">System Settings & backups</h1>
          <p className="text-sm text-gray-500 mt-1">Configure school profiles, supervise action histories, and trigger offline database backups.</p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => { setActiveTab('profile'); setSuccessMsg(''); setErrorMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'profile' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            School profile
          </button>
          <button
            onClick={() => { setActiveTab('backup'); setSuccessMsg(''); setErrorMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'backup' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Database backup & recover
          </button>
          <button
            onClick={() => { setActiveTab('audit'); setSuccessMsg(''); setErrorMsg(''); }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-all ${
              activeTab === 'audit' ? 'bg-white text-slate-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            Activity Audit Trail
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-xl max-w-4xl mx-auto">
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3 bg-red-50 border border-red-50 text-red-600 text-xs font-semibold rounded-xl max-w-4xl mx-auto flex items-center gap-2">
          <AlertTriangle size={15} />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* VIEW TABS SEGMENTS */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-2xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-3 mb-4">
            <h3 className="font-semibold text-gray-800 text-sm flex items-center gap-1.5">
              <Settings size={15} />
              <span>General School Profile Registry</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Parameters configured here dynamically populate receipt structures and transcripts.</p>
          </div>

          <form onSubmit={handleUpdateGeneralSettings} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Registered Institution Name</label>
              <input
                type="text"
                required
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="Institution Name"
                className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline bg-white font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase">Academic Term / Year</label>
                <input
                  type="text"
                  required
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  placeholder="e.g. 2025/2026"
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline bg-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase">Contact Telephone Line *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded focus:outline h-fit"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Administration Email *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase">Physical Address Coordinates</label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Institutional address"
                className="w-full mt-1.5 px-3 py-2 text-xs border border-gray-200 rounded bg-white"
              />
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-lg transition-colors cursor-pointer"
              >
                Publish Administrative Settings
              </button>
            </div>
          </form>
        </div>
      )}

      {activeTab === 'backup' && (
        <div className="max-w-xl mx-auto grid grid-cols-1 gap-6 animate-in fade-in duration-250">
          
          <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs space-y-4">
            <h3 className="font-semibold text-gray-800 text-sm flex items-center gap-1.5 border-b border-gray-50 pb-3">
              <Database size={15} />
              <span>Offline Database Security & backing</span>
            </h3>
            
            <p className="text-xs text-gray-500 leading-relaxed font-sans mt-2">
              AL-irshaad stands as an offline desktop system context. Since data resides completely locally on your current browser container storage, backing up records frequently prevents hardware data loss.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-3">
              {/* Back up */}
              <button
                type="button"
                onClick={onBackupDatabase}
                className="p-4 bg-slate-50 border border-slate-150 hover:bg-slate-100/50 rounded-xl transition-all cursor-pointer text-center space-y-2 flex flex-col items-center justify-center font-sans"
              >
                <Download size={22} className="text-slate-800" />
                <span className="font-bold text-xs block text-slate-900">Dump Database Backup</span>
                <span className="text-[10px] text-gray-400 uppercase tracking-wide">Export to .JSON</span>
              </button>

              {/* Restore */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-4 bg-slate-50 border border-slate-150 hover:bg-slate-100/50 rounded-xl transition-all cursor-pointer text-center space-y-2 flex flex-col items-center justify-center font-sans"
              >
                <Upload size={22} className="text-slate-800" />
                <span className="font-bold text-xs block text-slate-900">Restore School State</span>
                <span className="text-[10px] text-gray-400 uppercase tracking-wide">Import .JSON</span>
              </button>
              
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleUploadBackup}
                className="hidden"
              />
            </div>
          </div>

          <div className="bg-red-50/50 border border-red-100 rounded-xl p-5 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-red-700 flex items-center gap-1">
              <AlertTriangle size={15} />
              <span>Emergency System Factory Reset</span>
            </h4>
            <p className="text-[11px] text-red-650 leading-relaxed">
              This action purges current localStorage tables and rolls back the application schemas to the initial Mogadishu School onboarding reference dataset.
            </p>
            {activeUser.role === UserRole.ADMIN_LIMITED ? (
              <div className="bg-amber-50 border border-amber-200/60 p-3 rounded-lg text-amber-850 text-xs font-medium space-y-1.5">
                <p>⚠️ factory reset locked for role: <strong>{activeUser.role}</strong></p>
                <p className="font-normal opacity-90">Your administrative session doesn't hold delete authority scope over system tables.</p>
                <button
                  type="button"
                  disabled
                  className="bg-slate-200 text-slate-400 border border-slate-300 rounded text-xs font-semibold px-4 py-2 cursor-not-allowed transition-colors"
                >
                  Flush Database Tables (Locked)
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  if (window.confirm('Delete local tables and roll back schemas to factory defaults? This action is irreversible.')) {
                    onResetDatabaseToDefault();
                    setSuccessMsg('System records reset to Mogadishu reference state!');
                    setTimeout(() => setSuccessMsg(''), 4500);
                  }
                }}
                className="bg-red-600 hover:bg-red-700 text-white rounded text-xs font-semibold px-4 py-2 cursor-pointer transition-colors"
              >
                Flush Database Tables
              </button>
            )}
          </div>

        </div>
      )}

      {activeTab === 'audit' && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-250">
          <div className="border-b border-gray-50 pb-3 mb-4">
            <h3 className="font-semibold text-gray-800 text-sm flex items-center gap-2">
              <Activity size={15} />
              <span>Admin Activity Audit logs</span>
            </h3>
            <p className="text-xs text-gray-400 mt-1">Real-time un-alterable timeline sequence recording administrative and billing corrections.</p>
          </div>

          {/* Audit Trail List Timeline */}
          <div className="relative border-l border-gray-150 ml-3.5 pl-6 space-y-5 py-2 max-h-[400px] overflow-y-auto">
            {auditLogs.length === 0 ? (
              <p className="text-xs text-gray-400">Activity logging sequences initiated.</p>
            ) : (
              [...auditLogs].reverse().map(log => (
                <div key={log.id} className="relative text-xs">
                  {/* Circle Indicator on vertical rule */}
                  <span className="absolute -left-[30px] top-0.5 w-[9px] h-[9px] rounded-full border-2 border-slate-900 bg-white"></span>
                  
                  <div className="space-y-1">
                    <p className="text-gray-400 font-mono font-medium text-[11px]">{new Date(log.timestamp).toLocaleString()}</p>
                    <p className="font-semibold text-gray-900 font-sans">{log.action}</p>
                    <p className="text-gray-500 font-medium">{log.newValue}</p>
                    <p className="text-[10px] text-slate-800 font-bold bg-slate-100 px-1.5 py-0.5 rounded w-fit">
                      User Context: {log.userId} ({log.userRole}) | Table: {log.tableName}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
