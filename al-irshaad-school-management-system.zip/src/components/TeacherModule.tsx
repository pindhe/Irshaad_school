import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  X, 
  Mail, 
  Phone, 
  Calendar, 
  Award, 
  CheckSquare, 
  BookOpen, 
  Check, 
  UserCheck 
} from 'lucide-react';
import { Staff, Subject, User, AttendanceStatus, UserRole } from '../types';

interface TeacherModuleProps {
  staffList: Staff[];
  subjects: Subject[];
  activeUser: User;
  onAddStaff: (staff: Omit<Staff, 'id' | 'isActive'>) => void;
  onUpdateStaff: (staff: Staff) => void;
  onDeleteStaff: (id: string) => void;
  onLogAction: (action: string, tableName: string, recordId: string, details: string) => void;
}

interface StaffAttendanceRecord {
  staffId: string;
  name: string;
  status: AttendanceStatus;
  remarks: string;
}

export default function TeacherModule({
  staffList,
  subjects,
  activeUser,
  onAddStaff,
  onUpdateStaff,
  onDeleteStaff,
  onLogAction
}: TeacherModuleProps) {
  const [activeTab, setActiveTab] = useState<'directory' | 'attendance'>('directory');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddStaffModalOpen, setIsAddStaffModalOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);

  // Form States for Add Staff
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [designation, setDesignation] = useState('');
  const [assignedSubjectIds, setAssignedSubjectIds] = useState<string[]>([]);
  const [errorMsg, setErrorMsg] = useState('');

  // Daily Teacher Attendance Tracker state
  const [attendanceDate, setAttendanceDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [staffAttendanceList, setStaffAttendanceList] = useState<StaffAttendanceRecord[]>([]);
  const [attendanceSavedMsg, setAttendanceSavedMsg] = useState('');

  // Initialize/retrieve staff list for attendance on entry
  const initStaffAttendance = () => {
    const list: StaffAttendanceRecord[] = staffList.map(s => ({
      staffId: s.id,
      name: `${s.firstName} ${s.lastName}`,
      status: AttendanceStatus.PRESENT,
      remarks: ''
    }));
    setStaffAttendanceList(list);
    setAttendanceSavedMsg('');
  };

  React.useEffect(() => {
    initStaffAttendance();
  }, [staffList]);

  // Filters
  const filteredStaff = staffList.filter(staff => {
    const fullName = `${staff.firstName} ${staff.lastName}`.toLowerCase();
    const matchesSearch = 
      fullName.includes(searchQuery.toLowerCase()) || 
      staff.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.designation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const getSubjectName = (subId: string) => {
    return subjects.find(s => s.id === subId)?.subjectName || 'Unknown';
  };

  const handleToggleSubject = (subId: string) => {
    if (assignedSubjectIds.includes(subId)) {
      setAssignedSubjectIds(prev => prev.filter(id => id !== subId));
    } else {
      setAssignedSubjectIds(prev => [...prev, subId]);
    }
  };

  const handleSubmitStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !contactNumber || !email || !designation) {
      setErrorMsg('Please input all required values.');
      return;
    }

    onAddStaff({
      firstName,
      lastName,
      gender,
      contactNumber,
      email,
      employmentDate: new Date().toISOString().split('T')[0],
      designation,
      subjectsTaught: assignedSubjectIds
    });

    // Reset Form
    setFirstName('');
    setLastName('');
    setGender('Male');
    setContactNumber('');
    setEmail('');
    setDesignation('');
    setAssignedSubjectIds([]);
    setErrorMsg('');
    setIsAddStaffModalOpen(false);
  };

  const handleUpdateAttendanceStatus = (index: number, status: AttendanceStatus) => {
    const updated = [...staffAttendanceList];
    updated[index].status = status;
    setStaffAttendanceList(updated);
  };

  const handleUpdateAttendanceRemarks = (index: number, val: string) => {
    const updated = [...staffAttendanceList];
    updated[index].remarks = val;
    setStaffAttendanceList(updated);
  };

  const handleSaveStaffAttendance = (e: React.FormEvent) => {
    e.preventDefault();
    setAttendanceSavedMsg('Attendance saved successfully!');
    onLogAction(
      'RECORD_STAFF_ATTENDANCE',
      'StaffAttendance',
      attendanceDate,
      `Saved attendance logs for ${staffAttendanceList.length} staff members for the date: ${attendanceDate}`
    );
    setTimeout(() => {
      setAttendanceSavedMsg('');
    }, 4000);
  };

  return (
    <div className="space-y-6">
      {/* Module Header & Sub-Navigation Tabs */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-2">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 font-sans tracking-tight">Teacher & Staff Management</h1>
          <p className="text-sm text-gray-500 mt-1">Audit administrative staff roles, timetables, academic allocations, and checklists.</p>
        </div>
        <div className="flex gap-2 mt-4 md:mt-0">
          <button
            onClick={() => {
              setActiveTab('directory');
              setSearchQuery('');
            }}
            className={`px-4 py-2 text-sm font-semibold rounded-lg cursor-pointer transition-colors ${
              activeTab === 'directory' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'bg-white hover:bg-slate-50 text-gray-600 border border-gray-100'
            }`}
          >
            Staff Directory
          </button>
          <button
            onClick={() => {
              setActiveTab('attendance');
              initStaffAttendance();
            }}
            className={`px-4 py-2 text-sm font-semibold rounded-lg cursor-pointer transition-colors ${
              activeTab === 'attendance' 
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'bg-white hover:bg-slate-50 text-gray-600 border border-gray-100'
            }`}
          >
            Daily Attendance Entry
          </button>
        </div>
      </div>

      {activeTab === 'directory' ? (
        /* DIRECTORY VIEW */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-200">
          
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-xs space-y-4">
              <div className="flex justify-between items-center gap-3 flex-wrap">
                <div className="relative w-full max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={17} />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by staff name, specialty..."
                    className="w-full pl-9 pr-4 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                  />
                </div>
                <button
                  onClick={() => setIsAddStaffModalOpen(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-lg cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  <span>Onboard Staff</span>
                </button>
              </div>

              {/* Staff Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider">
                      <th className="py-3 px-4 font-semibold">Staff ID</th>
                      <th className="py-3 px-4 font-semibold">Name</th>
                      <th className="py-3 px-4 font-semibold">Designation</th>
                      <th className="py-3 px-4 font-semibold">Contact Phone</th>
                      <th className="py-3 px-4 font-semibold">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-sm">
                    {filteredStaff.map(staff => (
                      <tr 
                        key={staff.id} 
                        onClick={() => setSelectedStaff(staff)}
                        className={`hover:bg-slate-50/50 transition-colors cursor-pointer ${selectedStaff?.id === staff.id ? 'bg-slate-50' : ''}`}
                      >
                        <td className="py-3.5 px-4 font-mono text-xs font-semibold text-gray-500">{staff.id}</td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-gray-900">{staff.firstName} {staff.lastName}</div>
                          <div className="text-xs text-gray-400 mt-0.5">{staff.email}</div>
                        </td>
                        <td className="py-3.5 px-4 text-gray-700 text-xs font-medium bg-slate-50 border-r border-l border-zinc-150 inline-block rounded-md px-1.5 mt-2.5">{staff.designation}</td>
                        <td className="py-3.5 px-4 text-gray-500 text-xs">{staff.contactNumber}</td>
                        <td className="py-3.5 px-4">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${
                            staff.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'
                          }`}>
                            {staff.isActive ? 'Active Staff' : 'Suspended'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <button 
                            onClick={() => setSelectedStaff(staff)}
                            className="text-xs font-semibold text-slate-800 bg-gray-100 hover:bg-gray-200 px-2 rounded py-1 cursor-pointer"
                          >
                            Assign Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            {selectedStaff ? (
              <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs space-y-4 animate-in slide-in-from-right duration-250 sticky top-6">
                <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                  <div className="flex items-center gap-2">
                    <AwardsIcon />
                    <div>
                      <h3 className="font-semibold text-gray-900">{selectedStaff.firstName} {selectedStaff.lastName}</h3>
                      <p className="text-xs text-gray-400 mt-0.5 font-mono">{selectedStaff.id}</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedStaff(null)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                    <X size={16} />
                  </button>
                </div>

                <div className="space-y-3 text-sm">
                  <div>
                    <span className="text-xs font-semibold text-gray-400 block uppercase">Specialty & Assignment</span>
                    <p className="text-gray-800 font-medium mt-1 font-sans">{selectedStaff.designation}</p>
                  </div>

                  <div className="pt-2">
                    <span className="text-xs font-semibold text-gray-400 block uppercase mb-1">Subjects Allocated</span>
                    {selectedStaff.subjectsTaught.length === 0 ? (
                      <p className="text-xs text-gray-400 italic">No academic subjects assigned yet.</p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                        {selectedStaff.subjectsTaught.map(subId => (
                          <span key={subId} className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                            {getSubjectName(subId)}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 pt-3 border-t border-gray-50 text-xs text-gray-500">
                    <div className="flex items-center gap-2">
                      <Mail size={13} />
                      <span>{selectedStaff.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone size={13} />
                      <span>{selectedStaff.contactNumber}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar size={13} />
                      <span>Contract start date: {selectedStaff.employmentDate}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 flex gap-2">
                  <button
                    onClick={() => {
                      const updated = { ...selectedStaff, isActive: !selectedStaff.isActive };
                      onUpdateStaff(updated);
                      setSelectedStaff(updated);
                      onLogAction(
                        'STAFF_MUTATION',
                        'Staff',
                        selectedStaff.id,
                        `Status for staff member ${selectedStaff.firstName} has been marked ${updated.isActive ? 'Active' : 'Suspended'}`
                      );
                    }}
                    className={`flex-1 text-center py-2 text-xs rounded-lg font-semibold border cursor-pointer ${
                      selectedStaff.isActive 
                        ? 'bg-red-50 hover:bg-red-100 text-red-600 border-red-100' 
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border-emerald-110'
                    }`}
                  >
                    {selectedStaff.isActive ? 'Suspend Staff Member' : 'Activate Staff'}
                  </button>
                </div>

                {/* Deletion Control with RBAC Checks */}
                <div className="border-t border-slate-100 pt-4 mt-3">
                  <span className="text-[10px] text-gray-450 font-bold uppercase tracking-wider block mb-2 leading-none">Record Deletion (RBAC Enforcement)</span>
                  {activeUser.role === UserRole.ADMIN_LIMITED ? (
                    <div className="bg-amber-50 border border-amber-100 rounded-lg p-3">
                      <p className="text-[11px] text-amber-800 font-medium leading-relaxed font-sans">
                        ⚠️ Your role <strong>{activeUser.role}</strong> only allows <strong>Add / Update</strong> access. Only <strong>Administrator</strong> can delete records.
                      </p>
                      <button
                        type="button"
                        disabled
                        className="w-full mt-2 bg-slate-100 text-slate-400 border border-slate-200 text-xs font-semibold py-2 rounded-lg cursor-not-allowed flex items-center justify-center gap-1.5"
                      >
                        Delete Teacher Record (Locked)
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`Are you absolutely sure you want to permanently delete staff member ${selectedStaff.firstName} ${selectedStaff.lastName}? This action cannot be undone.`)) {
                          onDeleteStaff(selectedStaff.id);
                          onLogAction('STAFF_DELETION', 'Staff', selectedStaff.id, `Permanently deleted staff record: ${selectedStaff.firstName} ${selectedStaff.lastName}`);
                          setSelectedStaff(null);
                        }
                      }}
                      className="w-full bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 text-xs font-semibold py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 font-sans"
                    >
                      Delete Teacher Record
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 border border-dashed border-gray-200 rounded-xl p-8 py-12 text-center text-gray-400 flex flex-col items-center justify-center">
                <Users size={32} className="text-slate-300 mb-2" />
                <h4 className="text-sm font-semibold">Inspect Staff Records</h4>
                <p className="text-xs mt-1 text-gray-400 max-w-[200px]">Select any member of the staff directory to edit their qualifications or toggle permissions.</p>
              </div>
            )}
          </div>

        </div>
      ) : (
        /* DAILY STAFF ATTENDANCE CHECKLIST */
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-xs max-w-4xl mx-auto animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-gray-50 pb-4 mb-4">
            <div className="flex items-center gap-2.5">
              <UserCheck size={18} className="text-slate-900" />
              <h3 className="font-semibold text-gray-800">Faculty & Staff Attendance Register</h3>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-gray-400 uppercase">Registry Date:</span>
              <input
                type="date"
                value={attendanceDate}
                onChange={(e) => setAttendanceDate(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 focus:outline-hidden font-semibold font-mono"
              />
            </div>
          </div>

          {attendanceSavedMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-700 text-xs font-semibold mb-4">
              {attendanceSavedMsg}
            </div>
          )}

          <form onSubmit={handleSaveStaffAttendance} className="space-y-4">
            <div className="divide-y divide-gray-100">
              {staffAttendanceList.map((record, index) => (
                <div key={record.staffId} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold text-sm text-gray-800">{record.name}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{staffList.find(s => s.id === record.staffId)?.designation || 'Staff'}</p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex bg-slate-100 p-0.5 rounded-lg">
                      {Object.values(AttendanceStatus).map(status => (
                        <button
                          key={status}
                          type="button"
                          onClick={() => handleUpdateAttendanceStatus(index, status)}
                          className={`px-2.5 py-1 text-xs rounded-md transition-all font-semibold font-sans cursor-pointer ${
                            record.status === status 
                              ? status === AttendanceStatus.PRESENT 
                                ? 'bg-emerald-500 text-white shadow-xs' 
                                : status === AttendanceStatus.ABSENT 
                                ? 'bg-red-500 text-white shadow-xs' 
                                : status === AttendanceStatus.LATE 
                                ? 'bg-amber-500 text-white shadow-xs' 
                                : 'bg-blue-500 text-white shadow-xs'
                              : 'text-gray-500 hover:text-gray-800'
                          }`}
                        >
                          {status}
                        </button>
                      ))}
                    </div>

                    <input
                      type="text"
                      placeholder="Comment / Notes"
                      value={record.remarks}
                      onChange={(e) => handleUpdateAttendanceRemarks(index, e.target.value)}
                      className="px-2 py-1 border border-gray-150 rounded text-xs w-36 sm:w-48 focus:outline-hidden text-gray-600"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-5 border-t border-gray-100">
              <button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-5 py-2.5 rounded-lg transition-colors cursor-pointer"
              >
                Publish Registry Logs
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ADD STAFF MODAL */}
      {isAddStaffModalOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white rounded-xl shadow-xl border border-gray-100 w-full max-w-lg overflow-hidden">
            <div className="bg-slate-50 border-b border-gray-100 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users size={18} className="text-slate-800" />
                <h3 className="font-semibold text-gray-900 text-sm">Add New Staff / Instructor</h3>
              </div>
              <button onClick={() => setIsAddStaffModalOpen(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmitStaff} className="p-5 space-y-4">
              {errorMsg && (
                <div className="p-2.5 bg-red-50 border border-red-50 text-red-600 text-xs font-semibold rounded">
                  {errorMsg}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">First Name *</label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. Mahad"
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Farah"
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Gender *</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as 'Male' | 'Female')}
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Assigned Designation *</label>
                  <input
                    type="text"
                    required
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    placeholder="e.g. History Instructor"
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Contact Number *</label>
                  <input
                    type="text"
                    required
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    placeholder="e.g. +252 61 550..."
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Professional Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. name@al-irshaad.edu"
                    className="w-full mt-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Subject Authorization</label>
                <div className="bg-slate-50 border border-slate-100 p-2 rounded-lg grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto">
                  {subjects.map(sub => (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => handleToggleSubject(sub.id)}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs transition-colors cursor-pointer text-left ${
                        assignedSubjectIds.includes(sub.id) 
                          ? 'bg-slate-900 text-white' 
                          : 'bg-white hover:bg-slate-100 border border-zinc-150 text-gray-700'
                      }`}
                    >
                      <Check size={11} className={assignedSubjectIds.includes(sub.id) ? 'opacity-100' : 'opacity-0'} />
                      <span>{sub.subjectName}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
                <button
                  type="button"
                  onClick={() => setIsAddStaffModalOpen(false)}
                  className="px-4 py-1.5 text-xs text-gray-500 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded-md cursor-pointer font-bold"
                >
                  Submit Roll Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Internal small aesthetic helpers
function AwardsIcon() {
  return (
    <div className="w-10 h-10 bg-slate-900 text-white flex items-center justify-center rounded-xl shrink-0">
      <Award size={18} />
    </div>
  );
}
