import React, { useState } from 'react';
import { Shield, Lock, Users, AlertCircle, Sparkles } from 'lucide-react';
import { User, UserRole } from '../types';

interface LoginPageProps {
  users: User[];
  onLogin: (userId: string) => void;
}

export default function LoginPage({ users, onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setError('Please provide username and security code.');
      return;
    }

    setIsLoading(true);

    // Simulate localized delay for polished look
    setTimeout(() => {
      setIsLoading(false);
      
      if (cleanUser === 'administrator' && cleanPass === '123') {
        // Find U-001 (Administrator - Farah Aden)
        const fullAdmin = users.find(u => u.role === UserRole.ADMIN) || users[0];
        onLogin(fullAdmin.id);
      } else if (cleanUser === 'admin' && cleanPass === '123') {
        // Find U-008 (Admin Limited - Halima Ali)
        const limitedAdmin = users.find(u => u.role === UserRole.ADMIN_LIMITED) || users.find(u => u.id === 'U-008') || users[0];
        onLogin(limitedAdmin.id);
      } else {
        setError('Security handshake failed. Invalid username or password configuration.');
      }
    }, 600);
  };

  const handleFillPreset = (userType: 'administrator' | 'admin') => {
    setUsername(userType);
    setPassword('123');
    setError('');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden font-sans">
      
      {/* Decorative localized grid mesh styling */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-25" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/5 rounded-full filter blur-3xl" />
      
      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="flex justify-center">
          <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center text-slate-950 font-black text-xl tracking-tighter shadow-lg ring-4 ring-slate-900 border border-slate-800">
            AR
          </div>
        </div>
        <h2 className="mt-5 text-center text-2xl font-extrabold tracking-tight text-white uppercase">
          AL-irshaad School
        </h2>
        <p className="mt-1.5 text-center text-xs text-slate-400 font-medium tracking-wide uppercase">
          OFFLINE CENTRAL MANAGEMENT GATEWAY · MOGADISHU
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="bg-slate-900 border border-slate-800/80 rounded-2xl shadow-2xl p-8 relative">
          
          <div className="absolute top-0 right-8 -translate-y-1/2 bg-emerald-950/80 text-emerald-400 border border-emerald-800/50 rounded-full px-2.5 py-0.5 text-[9px] font-bold tracking-wider uppercase flex items-center gap-1">
            <Sparkles size={8} />
            <span>Secure TLS Node</span>
          </div>

          <form className="space-y-5" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="username" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Administrative ID (Username)
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Users size={16} />
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter administrator / admin"
                  className="bg-slate-950 border border-slate-800 focus:border-slate-500 focus:ring-1 focus:ring-slate-500 text-white rounded-lg pl-10 pr-3 py-2.5 w-full text-sm block placeholder-slate-600 font-sans tracking-wide transition-all"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Security Code (Password)
              </label>
              <div className="relative rounded-lg shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Lock size={16} />
                </div>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="bg-slate-950 border border-slate-800 focus:border-slate-500 focus:ring-1 focus:ring-slate-500 text-white rounded-lg pl-10 pr-3 py-2.5 w-full text-sm block placeholder-slate-600 font-sans tracking-wide transition-all"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-950/50 border border-red-900/60 rounded-xl p-3 flex gap-2.5 items-start">
                <AlertCircle className="text-red-400 shrink-0 mt-0.5" size={15} />
                <span className="text-xs text-red-300 font-medium leading-relaxed font-sans">{error}</span>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-slate-100 hover:bg-white text-slate-950 font-bold py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider border border-transparent shadow-sm hover:shadow-md cursor-pointer transition-all flex items-center justify-center gap-2 duration-150 active:scale-98 disabled:opacity-50 disabled:scale-100"
              >
                {isLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                    <span>Establishing Socket...</span>
                  </>
                ) : (
                  <>
                    <Shield size={14} />
                    <span>Authorize & Access Session</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Quick preset account links */}
          <div className="mt-8 pt-6 border-t border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block text-center mb-3">
              Standard Access Presets
            </span>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleFillPreset('administrator')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl p-3 text-left transition-all leading-relaxed cursor-pointer active:scale-95 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">Administrator</span>
                  <span className="text-xs text-slate-300 font-bold block mt-0.5">Farah Aden</span>
                </div>
                <div className="mt-2 text-[9px] text-slate-500 font-mono flex flex-col">
                  <span>ID: administrator</span>
                  <span>Pass: 123</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleFillPreset('admin')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl p-3 text-left transition-all leading-relaxed cursor-pointer active:scale-95 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">Admin (Restricted)</span>
                  <span className="text-xs text-slate-300 font-bold block mt-0.5">Halima Ali</span>
                </div>
                <div className="mt-2 text-[9px] text-slate-500 font-mono flex flex-col">
                  <span>ID: admin</span>
                  <span>Pass: 123</span>
                </div>
              </button>
            </div>
          </div>

        </div>

        {/* Local device storage indicator */}
        <p className="mt-6 text-center text-[10px] text-slate-500 font-sans leading-relaxed tracking-wide uppercase">
          🔒 Encrypted transaction keys saved on localized client tables.
        </p>
      </div>
    </div>
  );
}
