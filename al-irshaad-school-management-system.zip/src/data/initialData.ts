import {
  User,
  UserRole,
  Class,
  Section,
  Student,
  Staff,
  Subject,
  StudentAttendance,
  Exam,
  Mark,
  FeeCategory,
  FeeStructure,
  Payment,
  Book,
  Borrowing,
  TimetableEntry,
  AuditLog,
  SchoolSettings,
  AttendanceStatus
} from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'U-001',
    username: 'admin',
    firstName: 'Farah',
    lastName: 'Aden',
    role: UserRole.ADMIN,
    email: 'admin@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-008',
    username: 'clerk_admin',
    firstName: 'Halima',
    lastName: 'Ali',
    role: UserRole.ADMIN_LIMITED,
    email: 'halima.admin@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-002',
    username: 'principal',
    firstName: 'Yusuf',
    lastName: 'Gure',
    role: UserRole.PRINCIPAL,
    email: 'principal@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-003',
    username: 'mahad',
    firstName: 'Mahad',
    lastName: 'Farah',
    role: UserRole.TEACHER,
    email: 'mahad@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-004',
    username: 'amina',
    firstName: 'Amina',
    lastName: 'Said',
    role: UserRole.TEACHER,
    email: 'amina@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-005',
    username: 'accountant',
    firstName: 'Ahmed',
    lastName: 'Ali',
    role: UserRole.ACCOUNTANT,
    email: 'billing@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-006',
    username: 'librarian',
    firstName: 'Fadumo',
    lastName: 'Warsame',
    role: UserRole.LIBRARIAN,
    email: 'library@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=faces'
  },
  {
    id: 'U-007',
    username: 'registrar',
    firstName: 'Abdi',
    lastName: 'Osman',
    role: UserRole.REGISTRAR,
    email: 'registrar@al-irshaad.edu',
    isActive: true,
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=faces'
  }
];

export const INITIAL_CLASSES: Class[] = [
  { id: 'C-01', className: 'Grade 9', academicYear: '2025/2026' },
  { id: 'C-02', className: 'Grade 10', academicYear: '2025/2026' },
  { id: 'C-03', className: 'Grade 11', academicYear: '2025/2026' },
  { id: 'C-04', className: 'Grade 12', academicYear: '2025/2026' }
];

export const INITIAL_SECTIONS: Section[] = [
  { id: 'S-01-A', classId: 'C-01', sectionName: 'Section A' },
  { id: 'S-01-B', classId: 'C-01', sectionName: 'Section B' },
  { id: 'S-02-A', classId: 'C-02', sectionName: 'Section A' },
  { id: 'S-02-B', classId: 'C-02', sectionName: 'Section B' },
  { id: 'S-03-A', classId: 'C-03', sectionName: 'Section A' },
  { id: 'S-04-A', classId: 'C-04', sectionName: 'Section A' }
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: 'SUB-01', subjectName: 'Mathematics', subjectCode: 'MATH101' },
  { id: 'SUB-02', subjectName: 'English Language', subjectCode: 'ENG101' },
  { id: 'SUB-03', subjectName: 'Physics', subjectCode: 'PHYS101' },
  { id: 'SUB-04', subjectName: 'Chemistry', subjectCode: 'CHEM101' },
  { id: 'SUB-05', subjectName: 'Biology', subjectCode: 'BIOL101' },
  { id: 'SUB-06', subjectName: 'Arabic Literature', subjectCode: 'ARA101' },
  { id: 'SUB-07', subjectName: 'Islamic Studies', subjectCode: 'ISL101' },
  { id: 'SUB-08', subjectName: 'Somali Language', subjectCode: 'SOM101' },
  { id: 'SUB-09', subjectName: 'History & Geography', subjectCode: 'HIST101' }
];

export const INITIAL_STAFF: Staff[] = [
  {
    id: 'ST-001',
    firstName: 'Mahad',
    lastName: 'Farah',
    gender: 'Male',
    contactNumber: '+252 61 5500123',
    email: 'mahad@al-irshaad.edu',
    employmentDate: '2019-09-01',
    designation: 'Senior Physics and Math Teacher',
    isActive: true,
    subjectsTaught: ['SUB-01', 'SUB-03']
  },
  {
    id: 'ST-002',
    firstName: 'Amina',
    lastName: 'Said',
    gender: 'Female',
    contactNumber: '+252 61 5500124',
    email: 'amina@al-irshaad.edu',
    employmentDate: '2020-09-01',
    designation: 'Chemistry & Biology Instructor',
    isActive: true,
    subjectsTaught: ['SUB-04', 'SUB-05']
  },
  {
    id: 'ST-003',
    firstName: 'Sheikh Usman',
    lastName: 'Bari',
    gender: 'Male',
    contactNumber: '+252 61 5500125',
    email: 'usman.bari@al-irshaad.edu',
    employmentDate: '2018-01-15',
    designation: 'Islamic Studies & Arabic Head',
    isActive: true,
    subjectsTaught: ['SUB-06', 'SUB-07']
  },
  {
    id: 'ST-004',
    firstName: 'Hussein',
    lastName: 'Kamil',
    gender: 'Male',
    contactNumber: '+252 61 5500126',
    email: 'hussein.kamil@al-irshaad.edu',
    employmentDate: '2021-10-10',
    designation: 'English & Somali Language Teacher',
    isActive: true,
    subjectsTaught: ['SUB-02', 'SUB-08']
  },
  {
    id: 'ST-005',
    firstName: 'Hassan',
    lastName: 'Nur',
    gender: 'Male',
    contactNumber: '+252 61 5500127',
    email: 'hassan.nur@al-irshaad.edu',
    employmentDate: '2022-09-01',
    designation: 'History and Geography Teacher',
    isActive: true,
    subjectsTaught: ['SUB-09']
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'AL-2026-0001',
    firstName: 'Mohamed',
    middleName: 'Farah',
    lastName: 'Ali',
    dateOfBirth: '21-03-2010',
    gender: 'Male',
    address: 'Waberi District, Ward 4',
    city: 'Mogadishu',
    parentName: 'Farah Ali Dhool',
    parentContact: '+252 61 9991111',
    parentEmail: 'farah.ali@gmail.com',
    admissionDate: '2025-08-15',
    classId: 'C-01', // Grade 9
    sectionId: 'S-01-A', // Section A
    isActive: true
  },
  {
    id: 'AL-2026-0002',
    firstName: 'Halima',
    middleName: 'Duale',
    lastName: 'Mumin',
    dateOfBirth: '15-08-2009',
    gender: 'Female',
    address: 'Hodan District, near Digfeer',
    city: 'Mogadishu',
    parentName: 'Duale Mumin Warsame',
    parentContact: '+252 61 9991112',
    parentEmail: 'duale.m@gmail.com',
    admissionDate: '2025-08-15',
    classId: 'C-01', // Grade 9
    sectionId: 'S-01-A',
    isActive: true
  },
  {
    id: 'AL-2026-0003',
    firstName: 'Yusuf',
    middleName: 'Abdi',
    lastName: 'Ibrahim',
    dateOfBirth: '05-12-2009',
    gender: 'Male',
    address: 'Boondheere, Airport Road',
    city: 'Mogadishu',
    parentName: 'Abdi Ibrahim Nur',
    parentContact: '+252 61 9992222',
    parentEmail: 'abdi.ibrahim@outlook.com',
    admissionDate: '2025-08-15',
    classId: 'C-01', // Grade 9
    sectionId: 'S-01-B',
    isActive: true
  },
  {
    id: 'AL-2026-0004',
    firstName: 'Aisha',
    middleName: 'Omar',
    lastName: 'Jama',
    dateOfBirth: '12-01-2008',
    gender: 'Female',
    address: 'Shingani, coastal road',
    city: 'Mogadishu',
    parentName: 'Omar Jama Barre',
    parentContact: '+252 61 9993333',
    parentEmail: 'omar.jama@hotmail.com',
    admissionDate: '2024-09-01',
    classId: 'C-02', // Grade 10
    sectionId: 'S-02-A',
    isActive: true
  },
  {
    id: 'AL-2026-0005',
    firstName: 'Anas',
    middleName: 'Hassan',
    lastName: 'Guled',
    dateOfBirth: '09-04-2008',
    gender: 'Male',
    address: 'Kaxda District, Sector 3',
    city: 'Mogadishu',
    parentName: 'Hassan Guled Elmi',
    parentContact: '+252 61 9994444',
    parentEmail: 'hassan.guled@yahoo.com',
    admissionDate: '2024-09-01',
    classId: 'C-02', // Grade 10
    sectionId: 'S-02-B',
    isActive: true
  },
  {
    id: 'AL-2026-0006',
    firstName: 'Saynab',
    middleName: 'Sharif',
    lastName: 'Adan',
    dateOfBirth: '22-11-2007',
    gender: 'Female',
    address: 'Dayniile, near local hospital',
    city: 'Mogadishu',
    parentName: 'Sharif Adan Isaq',
    parentContact: '+252 61 9995555',
    parentEmail: 'sharif.adan@gmail.com',
    admissionDate: '2023-09-01',
    classId: 'C-03', // Grade 11
    sectionId: 'S-03-A',
    isActive: true
  },
  {
    id: 'AL-2026-0007',
    firstName: 'Mustafa',
    middleName: 'Dahir',
    lastName: 'Hirsi',
    dateOfBirth: '03-03-2006',
    gender: 'Male',
    address: 'Yaqshid District',
    city: 'Mogadishu',
    parentName: 'Dahir Hirsi Bile',
    parentContact: '+252 61 9996666',
    parentEmail: 'dahir.hirsi@outlook.com',
    admissionDate: '2022-09-01',
    classId: 'C-04', // Grade 12
    sectionId: 'S-04-A',
    isActive: true
  }
];

export const INITIAL_ATTENDANCE: StudentAttendance[] = [
  // Attendance records for Grade 9 Section A for recent school days (e.g. today or yesterday)
  { id: 'ATT-001', studentId: 'AL-2026-0001', date: '2026-05-31', status: AttendanceStatus.PRESENT, recordedBy: 'mahad', timestamp: '2026-05-31T08:15:00Z' },
  { id: 'ATT-002', studentId: 'AL-2026-0002', date: '2026-05-31', status: AttendanceStatus.PRESENT, recordedBy: 'mahad', timestamp: '2026-05-31T08:15:05Z' },
  { id: 'ATT-003', studentId: 'AL-2026-0003', date: '2026-05-31', status: AttendanceStatus.PRESENT, recordedBy: 'mahad', timestamp: '2026-05-31T08:16:00Z' },
  { id: 'ATT-004', studentId: 'AL-2026-0001', date: '2026-06-01', status: AttendanceStatus.PRESENT, recordedBy: 'mahad', timestamp: '2026-06-01T08:10:00Z' },
  { id: 'ATT-005', studentId: 'AL-2026-0002', date: '2026-06-01', status: AttendanceStatus.ABSENT, remarks: 'Family event out of town', recordedBy: 'mahad', timestamp: '2026-06-01T08:10:35Z' },
  { id: 'ATT-006', studentId: 'AL-2026-0003', date: '2026-06-01', status: AttendanceStatus.PRESENT, recordedBy: 'mahad', timestamp: '2026-06-01T08:11:00Z' },
  { id: 'ATT-007', studentId: 'AL-2026-0004', date: '2026-06-01', status: AttendanceStatus.PRESENT, recordedBy: 'amina', timestamp: '2026-06-01T08:15:00Z' },
  { id: 'ATT-008', studentId: 'AL-2026-0005', date: '2026-06-01', status: AttendanceStatus.LATE, remarks: 'Traffic delay', recordedBy: 'amina', timestamp: '2026-06-01T08:18:22Z' }
];

export const INITIAL_EXAMS: Exam[] = [
  { id: 'EX-01', examName: 'Mid-term Exam', subjectId: 'SUB-01', classId: 'C-01', maxMarks: 100, examDate: '2026-04-10' },
  { id: 'EX-02', examName: 'Mid-term Exam', subjectId: 'SUB-03', classId: 'C-01', maxMarks: 100, examDate: '2026-04-12' },
  { id: 'EX-03', examName: 'Mid-term Exam', subjectId: 'SUB-04', classId: 'C-01', maxMarks: 100, examDate: '2026-04-14' },
  { id: 'EX-04', examName: 'Final Exam', subjectId: 'SUB-01', classId: 'C-01', maxMarks: 100, examDate: '2026-06-15' }
];

export const INITIAL_MARKS: Mark[] = [
  // Mohamed Farah Ali (AL-2026-0001) Mid-terms
  { id: 'M-001', studentId: 'AL-2026-0001', examId: 'EX-01', subjectId: 'SUB-01', marksObtained: 88, grade: 'A', recordedBy: 'mahad', timestamp: '2026-04-15T10:00:00Z' },
  { id: 'M-002', studentId: 'AL-2026-0001', examId: 'EX-02', subjectId: 'SUB-03', marksObtained: 92, grade: 'A+', recordedBy: 'mahad', timestamp: '2026-04-16T11:20:00Z' },
  { id: 'M-003', studentId: 'AL-2026-0001', examId: 'EX-03', subjectId: 'SUB-04', marksObtained: 79, grade: 'B+', recordedBy: 'amina', timestamp: '2026-04-17T09:30:00Z' },

  // Halima Duale Mumin (AL-2026-0002) Mid-terms
  { id: 'M-004', studentId: 'AL-2026-0002', examId: 'EX-01', subjectId: 'SUB-01', marksObtained: 95, grade: 'A+', recordedBy: 'mahad', timestamp: '2026-04-15T10:02:00Z' },
  { id: 'M-005', studentId: 'AL-2026-0002', examId: 'EX-02', subjectId: 'SUB-03', marksObtained: 85, grade: 'A', recordedBy: 'mahad', timestamp: '2026-04-16T11:22:00Z' },
  { id: 'M-006', studentId: 'AL-2026-0002', examId: 'EX-03', subjectId: 'SUB-04', marksObtained: 90, grade: 'A', recordedBy: 'amina', timestamp: '2026-04-17T09:32:00Z' },

  // Yusuf Abdi Ibrahim (AL-2026-0003) Mid-terms
  { id: 'M-007', studentId: 'AL-2026-0003', examId: 'EX-01', subjectId: 'SUB-01', marksObtained: 65, grade: 'C+', recordedBy: 'mahad', timestamp: '2026-04-15T10:05:00Z' },
  { id: 'M-008', studentId: 'AL-2026-0003', examId: 'EX-02', subjectId: 'SUB-03', marksObtained: 72, grade: 'B', recordedBy: 'mahad', timestamp: '2026-04-16T11:25:00Z' },
  { id: 'M-009', studentId: 'AL-2026-0003', examId: 'EX-03', subjectId: 'SUB-04', marksObtained: 68, grade: 'C+', recordedBy: 'amina', timestamp: '2026-04-17T09:35:00Z' }
];

export const INITIAL_FEE_CATEGORIES: FeeCategory[] = [
  { id: 'FC-01', categoryName: 'Tuition Fee (Annual)' },
  { id: 'FC-02', categoryName: 'Registration Fee' },
  { id: 'FC-03', categoryName: 'Library Fee' },
  { id: 'FC-04', categoryName: 'Exam & Lab Fee' }
];

export const INITIAL_FEE_STRUCTURES: FeeStructure[] = [
  // C-01 (Grade 9) structures
  { id: 'FS-01', classId: 'C-01', categoryId: 'FC-01', amount: 800, academicYear: '2025/2026' },
  { id: 'FS-02', classId: 'C-01', categoryId: 'FC-02', amount: 50, academicYear: '2025/2026' },
  { id: 'FS-03', classId: 'C-01', categoryId: 'FC-03', amount: 30, academicYear: '2025/2026' },
  { id: 'FS-04', classId: 'C-01', categoryId: 'FC-04', amount: 60, academicYear: '2025/2026' },

  // C-02 (Grade 10) structures
  { id: 'FS-05', classId: 'C-02', categoryId: 'FC-01', amount: 850, academicYear: '2025/2026' },
  { id: 'FS-06', classId: 'C-02', categoryId: 'FC-02', amount: 50, academicYear: '2025/2026' },
  { id: 'FS-07', classId: 'C-02', categoryId: 'FC-03', amount: 30, academicYear: '2025/2026' },
  { id: 'FS-08', classId: 'C-02', categoryId: 'FC-04', amount: 70, academicYear: '2025/2026' },

  // Grade 11
  { id: 'FS-09', classId: 'C-03', categoryId: 'FC-01', amount: 900, academicYear: '2025/2026' },
  { id: 'FS-10', classId: 'C-04', categoryId: 'FC-01', amount: 950, academicYear: '2025/2026' }
];

export const INITIAL_PAYMENTS: Payment[] = [
  {
    id: 'P-001',
    studentId: 'AL-2026-0001',
    categoryId: 'FC-01',
    amountPaid: 400,
    paymentDate: '2025-09-10',
    paymentMethod: 'Bank Transfer',
    receivedBy: 'accountant',
    remarks: 'First installment of Tuition',
    receiptNumber: 'REC-2025-1049'
  },
  {
    id: 'P-002',
    studentId: 'AL-2026-0001',
    categoryId: 'FC-02',
    amountPaid: 50,
    paymentDate: '2025-08-20',
    paymentMethod: 'Cash',
    receivedBy: 'accountant',
    remarks: 'New entry registration paid in full',
    receiptNumber: 'REC-2025-0902'
  },
  {
    id: 'P-003',
    studentId: 'AL-2026-0002',
    categoryId: 'FC-01',
    amountPaid: 800,
    paymentDate: '2025-09-02',
    paymentMethod: 'Mobile Money',
    receivedBy: 'accountant',
    remarks: 'Full Annual Tuition Paid',
    receiptNumber: 'REC-2025-1002'
  },
  {
    id: 'P-004',
    studentId: 'AL-2026-0003',
    categoryId: 'FC-01',
    amountPaid: 300,
    paymentDate: '2025-10-05',
    paymentMethod: 'Cash',
    receivedBy: 'accountant',
    remarks: 'First deposit',
    receiptNumber: 'REC-2025-1150'
  }
];

export const INITIAL_BOOKS: Book[] = [
  {
    id: 'B-001',
    title: 'University Physics with Modern Physics',
    author: 'Sears and Zemansky',
    isbn: '978-0131203105',
    publisher: 'Pearson Education',
    publicationYear: 2011,
    category: 'Physics',
    totalQuantity: 25,
    availableQuantity: 22
  },
  {
    id: 'B-002',
    title: 'Calculus: Early Transcendentals',
    author: 'James Stewart',
    isbn: '978-0538497909',
    publisher: 'Cengage Learning',
    publicationYear: 2015,
    category: 'Mathematics',
    totalQuantity: 30,
    availableQuantity: 27
  },
  {
    id: 'B-003',
    title: 'Concepts of Biology',
    author: 'Samantha Fowler',
    isbn: '978-1938168116',
    publisher: 'OpenStax',
    publicationYear: 2017,
    category: 'Biology',
    totalQuantity: 20,
    availableQuantity: 18
  },
  {
    id: 'B-004',
    title: 'Arabic Language and Composition',
    author: 'Dr. Mahmoud Al-Safar',
    isbn: '978-4301294020',
    publisher: 'Al-Azhar Publishing',
    publicationYear: 2020,
    category: 'Arabic',
    totalQuantity: 40,
    availableQuantity: 40
  },
  {
    id: 'B-005',
    title: 'Fiqh of Worship: A Commentary',
    author: 'Sheikh Ibn Qudamah',
    isbn: '978-1904336142',
    publisher: 'Darussalam',
    publicationYear: 2005,
    category: 'Islamic Studies',
    totalQuantity: 15,
    availableQuantity: 12
  }
];

export const INITIAL_BORROWINGS: Borrowing[] = [
  {
    id: 'BOR-001',
    bookId: 'B-001',
    studentId: 'AL-2026-0001',
    issueDate: '2026-05-15',
    dueDate: '2026-05-30',
    returnDate: '2026-05-29',
    isReturned: true,
    issuedBy: 'librarian'
  },
  {
    id: 'BOR-002',
    bookId: 'B-002',
    studentId: 'AL-2026-0002',
    issueDate: '2026-05-20',
    dueDate: '2026-06-03',
    isReturned: false,
    issuedBy: 'librarian'
  },
  {
    id: 'BOR-003',
    bookId: 'B-005',
    studentId: 'AL-2026-0003',
    issueDate: '2026-05-10',
    dueDate: '2026-05-24', // OVERDUE book!
    isReturned: false,
    issuedBy: 'librarian'
  }
];

export const INITIAL_TIMETABLE: TimetableEntry[] = [
  // Grade 9 A - Mon
  { id: 'T-001', classId: 'C-01', dayOfWeek: 'Monday', periodNumber: 1, startTime: '07:30', endTime: '08:15', subjectId: 'SUB-01', teacherId: 'ST-001', roomNumber: 'Room 12' },
  { id: 'T-002', classId: 'C-01', dayOfWeek: 'Monday', periodNumber: 2, startTime: '08:15', endTime: '09:00', subjectId: 'SUB-03', teacherId: 'ST-001', roomNumber: 'Room 12' },
  { id: 'T-003', classId: 'C-01', dayOfWeek: 'Monday', periodNumber: 3, startTime: '09:15', endTime: '10:00', subjectId: 'SUB-05', teacherId: 'ST-002', roomNumber: 'Room 12' },
  { id: 'T-004', classId: 'C-01', dayOfWeek: 'Monday', periodNumber: 4, startTime: '10:00', endTime: '10:45', subjectId: 'SUB-07', teacherId: 'ST-003', roomNumber: 'Room 12' },
  // Grade 9 A - Tue
  { id: 'T-005', classId: 'C-01', dayOfWeek: 'Tuesday', periodNumber: 1, startTime: '07:30', endTime: '08:15', subjectId: 'SUB-02', teacherId: 'ST-004', roomNumber: 'Room 12' },
  { id: 'T-006', classId: 'C-01', dayOfWeek: 'Tuesday', periodNumber: 2, startTime: '08:15', endTime: '09:00', subjectId: 'SUB-04', teacherId: 'ST-002', roomNumber: 'Room 12' },
  { id: 'T-007', classId: 'C-01', dayOfWeek: 'Tuesday', periodNumber: 3, startTime: '09:15', endTime: '10:00', subjectId: 'SUB-08', teacherId: 'ST-004', roomNumber: 'Room 12' },
  { id: 'T-008', classId: 'C-01', dayOfWeek: 'Tuesday', periodNumber: 4, startTime: '10:00', endTime: '10:45', subjectId: 'SUB-09', teacherId: 'ST-005', roomNumber: 'Room 12' }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  { id: 'L-001', userId: 'U-001', userRole: UserRole.ADMIN, action: 'SYSTEM_INSTALL', tableName: 'Settings', recordId: 'ALL', newValue: 'Initial school system online installation completed.', timestamp: '2026-05-20T06:00:00Z' },
  { id: 'L-002', userId: 'U-007', userRole: UserRole.REGISTRAR, action: 'STUDENT_ADMISSION', tableName: 'Students', recordId: 'AL-2026-0001', newValue: 'Admitted student Mohamed Farah Ali', timestamp: '2026-05-30T09:12:00Z' },
  { id: 'L-003', userId: 'U-005', userRole: UserRole.ACCOUNTANT, action: 'RECORD_FEE_PAYMENT', tableName: 'Payments', recordId: 'P-001', newValue: 'Tuition receipt generated for MOHAMED FARAH ALI (USD 400.00)', timestamp: '2026-05-31T11:42:00Z' }
];

export const INITIAL_SETTINGS: SchoolSettings = {
  schoolName: 'AL-irshaad Secondary School',
  academicYear: '2025/2026',
  address: '30th August Street, Waberi, Mogadishu, Somalia',
  phone: '+252 61 5000000',
  email: 'info@al-irshaad.edu',
  gradingScale: [
    { grade: 'A+', minPercentage: 95 },
    { grade: 'A', minPercentage: 85 },
    { grade: 'B+', minPercentage: 78 },
    { grade: 'B', minPercentage: 70 },
    { grade: 'C+', minPercentage: 62 },
    { grade: 'C', minPercentage: 50 },
    { grade: 'D', minPercentage: 40 },
    { grade: 'F', minPercentage: 0 }
  ]
};
