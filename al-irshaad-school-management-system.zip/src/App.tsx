import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  Coins, 
  BookOpen, 
  Settings, 
  Clock, 
  Activity, 
  Database, 
  Shield, 
  ChevronDown, 
  TrendingUp, 
  UserCheck, 
  AlertCircle,
  FolderSync,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Columns,
  Lock
} from 'lucide-react';

// Sub-modules
import StudentModule from './components/StudentModule';
import TeacherModule from './components/TeacherModule';
import AcademicModule from './components/AcademicModule';
import FinanceModule from './components/FinanceModule';
import LibraryModule from './components/LibraryModule';
import SettingsModule from './components/SettingsModule';
import LoginPage from './components/LoginPage';

// Types and mock data
import {
  User,
  UserRole,
  Class,
  Section,
  Student,
  Staff,
  Subject,
  StudentAttendance,
  Exam,
  Mark,
  FeeCategory,
  FeeStructure,
  Payment,
  Book,
  Borrowing,
  TimetableEntry,
  AuditLog,
  SchoolSettings,
  AttendanceStatus
} from './types';

import {
  INITIAL_USERS,
  INITIAL_CLASSES,
  INITIAL_SECTIONS,
  INITIAL_SUBJECTS,
  INITIAL_STAFF,
  INITIAL_STUDENTS,
  INITIAL_ATTENDANCE,
  INITIAL_EXAMS,
  INITIAL_MARKS,
  INITIAL_FEE_CATEGORIES,
  INITIAL_FEE_STRUCTURES,
  INITIAL_PAYMENTS,
  INITIAL_BOOKS,
  INITIAL_BORROWINGS,
  INITIAL_TIMETABLE,
  INITIAL_AUDIT_LOGS,
  INITIAL_SETTINGS
} from './data/initialData';

const LOCAL_STORAGE_DB_KEY = 'al_irshaad_offline_db';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'staff' | 'academics' | 'finance' | 'library' | 'settings'>('dashboard');

  // PERSISTED STATES & PREFERENCES
  const [isSidebarHidden, setIsSidebarHidden] = useState<boolean>(() => {
    return localStorage.getItem('al_irshaad_sidebar_hidden') === 'true';
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('al_irshaad_sidebar_collapsed') === 'true';
  });
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('al_irshaad_is_logged_in') === 'true';
  });

  // Sidebar mobile drawer toggle state
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // LOCAL DATABASE MASTER STATE
  const [activeUser, setActiveUser] = useState<User>(() => {
    const savedUserId = localStorage.getItem('al_irshaad_logged_in_user_id');
    const found = INITIAL_USERS.find(u => u.id === savedUserId);
    return found || INITIAL_USERS[0];
  });
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [schoolSettings, setSchoolSettings] = useState<SchoolSettings>(INITIAL_SETTINGS);
  
  const [classes, setClasses] = useState<Class[]>(INITIAL_CLASSES);
  const [sections, setSections] = useState<Section[]>(INITIAL_SECTIONS);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [staffList, setStaffList] = useState<Staff[]>(INITIAL_STAFF);
  const [attendanceLogs, setAttendanceLogs] = useState<StudentAttendance[]>(INITIAL_ATTENDANCE);
  const [exams, setExams] = useState<Exam[]>(INITIAL_EXAMS);
  const [marks, setMarks] = useState<Mark[]>(INITIAL_MARKS);
  
  const [feeCategories, setFeeCategories] = useState<FeeCategory[]>(INITIAL_FEE_CATEGORIES);
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>(INITIAL_FEE_STRUCTURES);
  const [payments, setPayments] = useState<Payment[]>(INITIAL_PAYMENTS);
  
  const [books, setBooks] = useState<Book[]>(INITIAL_BOOKS);
  const [borrowings, setBorrowings] = useState<Borrowing[]>(INITIAL_BORROWINGS);
  const [timetable, setTimetable] = useState<TimetableEntry[]>(INITIAL_TIMETABLE);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  // Load from local storage when initializing app
  useEffect(() => {
    const savedDb = localStorage.getItem(LOCAL_STORAGE_DB_KEY);
    if (savedDb) {
      try {
        const parsed = JSON.parse(savedDb);
        if (parsed.schoolSettings) setSchoolSettings(parsed.schoolSettings);
        if (parsed.classes) setClasses(parsed.classes);
        if (parsed.sections) setSections(parsed.sections);
        if (parsed.subjects) setSubjects(parsed.subjects);
        if (parsed.students) setStudents(parsed.students);
        if (parsed.staffList) setStaffList(parsed.staffList);
        if (parsed.attendanceLogs) setAttendanceLogs(parsed.attendanceLogs);
        if (parsed.exams) setExams(parsed.exams);
        if (parsed.marks) setMarks(parsed.marks);
        if (parsed.feeCategories) setFeeCategories(parsed.feeCategories);
        if (parsed.feeStructures) setFeeStructures(parsed.feeStructures);
        if (parsed.payments) setPayments(parsed.payments);
        if (parsed.books) setBooks(parsed.books);
        if (parsed.borrowings) setBorrowings(parsed.borrowings);
        if (parsed.timetable) setTimetable(parsed.timetable);
        if (parsed.auditLogs) setAuditLogs(parsed.auditLogs);
      } catch (err) {
        console.error('Error hydrating state from local offline storage:', err);
      }
    }
  }, []);

  // Write sidebar and navigation preferences to local storage whenever they change
  useEffect(() => {
    localStorage.setItem('al_irshaad_sidebar_hidden', String(isSidebarHidden));
  }, [isSidebarHidden]);

  useEffect(() => {
    localStorage.setItem('al_irshaad_sidebar_collapsed', String(isSidebarCollapsed));
  }, [isSidebarCollapsed]);

  // Write changes to local storage whenever DB Tables change
  const syncDatabaseWithLocalStorage = (updatedTables: Partial<{
    schoolSettings: SchoolSettings;
    classes: Class[];
    sections: Section[];
    subjects: Subject[];
    students: Student[];
    staffList: Staff[];
    attendanceLogs: StudentAttendance[];
    exams: Exam[];
    marks: Mark[];
    feeCategories: FeeCategory[];
    feeStructures: FeeStructure[];
    payments: Payment[];
    books: Book[];
    borrowings: Borrowing[];
    timetable: TimetableEntry[];
    auditLogs: AuditLog[];
  }>) => {
    // Get master state structure
    const currentStorageStr = localStorage.getItem(LOCAL_STORAGE_DB_KEY);
    let stateObj: any = {};
    if (currentStorageStr) {
      try { stateObj = JSON.parse(currentStorageStr); } catch (_) {}
    }

    const compiled = {
      schoolSettings: updatedTables.schoolSettings ?? schoolSettings,
      classes: updatedTables.classes ?? classes,
      sections: updatedTables.sections ?? sections,
      subjects: updatedTables.subjects ?? subjects,
      students: updatedTables.students ?? students,
      staffList: updatedTables.staffList ?? staffList,
      attendanceLogs: updatedTables.attendanceLogs ?? attendanceLogs,
      exams: updatedTables.exams ?? exams,
      marks: updatedTables.marks ?? marks,
      feeCategories: updatedTables.feeCategories ?? feeCategories,
      feeStructures: updatedTables.feeStructures ?? feeStructures,
      payments: updatedTables.payments ?? payments,
      books: updatedTables.books ?? books,
      borrowings: updatedTables.borrowings ?? borrowings,
      timetable: updatedTables.timetable ?? timetable,
      auditLogs: updatedTables.auditLogs ?? auditLogs,
    };

    localStorage.setItem(LOCAL_STORAGE_DB_KEY, JSON.stringify(compiled));
  };


  // AUDIT LOG HELPER
  const handleLogAction = (action: string, tableName: string, recordId: string, details: string) => {
    const newLog: AuditLog = {
      id: `L-${Date.now()}`,
      userId: activeUser.id,
      userRole: activeUser.role,
      action,
      tableName,
      recordId,
      newValue: details,
      timestamp: new Date().toISOString()
    };
    const updated = [...auditLogs, newLog];
    setAuditLogs(updated);
    syncDatabaseWithLocalStorage({ auditLogs: updated });
  };


  // MUTATIONS: STUDENTS
  const handleAddStudent = (formData: Omit<Student, 'id' | 'admissionDate' | 'isActive'>) => {
    const newIdNum = students.length + 1;
    const formattedId = `AL-2026-${String(newIdNum).padStart(4, '0')}`;
    const newStudent: Student = {
      ...formData,
      id: formattedId,
      admissionDate: new Date().toISOString().split('T')[0],
      isActive: true
    };
    const updated = [...students, newStudent];
    setStudents(updated);
    syncDatabaseWithLocalStorage({ students: updated });
    handleLogAction('STUDENT_ADMISSION', 'Students', formattedId, `Admitted new student: ${formData.firstName} ${formData.lastName}`);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    const updated = students.map(s => s.id === updatedStudent.id ? updatedStudent : s);
    setStudents(updated);
    syncDatabaseWithLocalStorage({ students: updated });
  };

  const handlePromoteStudent = (studentId: string, newClassId: string, newSectionId: string) => {
    const updated = students.map(s => s.id === studentId ? { ...s, classId: newClassId, sectionId: newSectionId } : s);
    setStudents(updated);
    syncDatabaseWithLocalStorage({ students: updated });
  };


  // MUTATIONS: STAFF
  const handleAddStaff = (formData: Omit<Staff, 'id' | 'isActive'>) => {
    const newIdVal = `ST-00${staffList.length + 1}`;
    const newStaff: Staff = {
      ...formData,
      id: newIdVal,
      isActive: true
    };
    const updated = [...staffList, newStaff];
    setStaffList(updated);
    syncDatabaseWithLocalStorage({ staffList: updated });
    handleLogAction('STAFF_ONBOARDING', 'Staff', newIdVal, `Onboarded new staff member: ${formData.firstName} ${formData.lastName}`);
  };

  const handleUpdateStaff = (updatedStaff: Staff) => {
    const updated = staffList.map(s => s.id === updatedStaff.id ? updatedStaff : s);
    setStaffList(updated);
    syncDatabaseWithLocalStorage({ staffList: updated });
  };


  // MUTATIONS: ACADEMICS / ATTENDANCE / MARKS
  const handleRecordAttendance = (records: Omit<StudentAttendance, 'id' | 'timestamp'>[]) => {
    // Generate IDs and timestamps
    const generated: StudentAttendance[] = records.map((r, i) => ({
      ...r,
      id: `ATT-${Date.now()}-${i}`,
      timestamp: new Date().toISOString()
    }));

    // Filter out previous logs matching same student and same date
    const studentIdsToReplace = records.map(r => r.studentId);
    const targetDate = records[0]?.date;
    const remaining = attendanceLogs.filter(log => !(studentIdsToReplace.includes(log.studentId) && log.date === targetDate));

    const updated = [...remaining, ...generated];
    setAttendanceLogs(updated);
    syncDatabaseWithLocalStorage({ attendanceLogs: updated });
  };

  const handleRecordMarks = (marksEntry: Omit<Mark, 'id' | 'timestamp'>[]) => {
    const generated: Mark[] = marksEntry.map((m, i) => ({
      ...m,
      id: `M-${Date.now()}-${i}`,
      timestamp: new Date().toISOString()
    }));

    // Replace previous marks matching same student and same exam
    const studentIds = marksEntry.map(r => r.studentId);
    const examTargetId = marksEntry[0]?.examId;
    const remaining = marks.filter(m => !(studentIds.includes(m.studentId) && m.examId === examTargetId));

    const updated = [...remaining, ...generated];
    setMarks(updated);
    syncDatabaseWithLocalStorage({ marks: updated });
  };

  const handleAddExam = (exam: Omit<Exam, 'id'>) => {
    const newExam: Exam = {
      ...exam,
      id: `EX-${Date.now()}`
    };
    const updated = [...exams, newExam];
    setExams(updated);
    syncDatabaseWithLocalStorage({ exams: updated });
  };


  // MUTATIONS: FINANCE / PAYMENTS
  const handleRecordPayment = (payment: Omit<Payment, 'id' | 'receiptNumber'>) => {
    const receiptNumVal = `REC-2026-${String(payments.length + 1051).padStart(4, '0')}`;
    const newPayment: Payment = {
      ...payment,
      id: `P-${Date.now()}`,
      receiptNumber: receiptNumVal
    };
    const updated = [...payments, newPayment];
    setPayments(updated);
    syncDatabaseWithLocalStorage({ payments: updated });
  };

  const handleAddFeeCategory = (categoryName: string) => {
    const newCategory: FeeCategory = {
      id: `FC-${String(feeCategories.length + 1).padStart(2, '0')}`,
      categoryName
    };
    const updated = [...feeCategories, newCategory];
    setFeeCategories(updated);
    syncDatabaseWithLocalStorage({ feeCategories: updated });
  };


  // MUTATIONS: LIBRARY
  const handleAddBook = (book: Omit<Book, 'id' | 'availableQuantity'>) => {
    const newBook: Book = {
      ...book,
      id: `B-${String(books.length + 1).padStart(3, '0')}`,
      availableQuantity: book.totalQuantity
    };
    const updated = [...books, newBook];
    setBooks(updated);
    syncDatabaseWithLocalStorage({ books: updated });
  };

  const handleIssueBook = (borrowing: Omit<Borrowing, 'id' | 'isReturned'>) => {
    // Subtract book copy
    const targetBook = books.find(b => b.id === borrowing.bookId);
    if (!targetBook || targetBook.availableQuantity <= 0) return;

    const updatedBooks = books.map(b => b.id === borrowing.bookId ? { ...b, availableQuantity: b.availableQuantity - 1 } : b);
    setBooks(updatedBooks);

    const newBorrow: Borrowing = {
      ...borrowing,
      id: `BOR-${String(borrowings.length + 1).padStart(3, '0')}`,
      isReturned: false
    };
    const updatedBorrowings = [...borrowings, newBorrow];
    setBorrowings(updatedBorrowings);

    syncDatabaseWithLocalStorage({ books: updatedBooks, borrowings: updatedBorrowings });
  };

  const handleReturnBook = (borrowingId: string) => {
    const borrowItem = borrowings.find(b => b.id === borrowingId);
    if (!borrowItem) return;

    // Put book copy back
    const updatedBooks = books.map(b => b.id === borrowItem.bookId ? { ...b, availableQuantity: b.availableQuantity + 1 } : b);
    setBooks(updatedBooks);

    const updatedBorrowings = borrowings.map(b => b.id === borrowingId ? { ...b, isReturned: true, returnDate: new Date().toISOString().split('T')[0] } : b);
    setBorrowings(updatedBorrowings);

    syncDatabaseWithLocalStorage({ books: updatedBooks, borrowings: updatedBorrowings });
  };


  // MUTATIONS: GENERAL RECORD DELETIONS (RBAC REGULATED)
  const handleDeleteStudent = (id: string) => {
    const updated = students.filter(s => s.id !== id);
    setStudents(updated);
    syncDatabaseWithLocalStorage({ students: updated });
  };

  const handleDeleteStaff = (id: string) => {
    const updated = staffList.filter(s => s.id !== id);
    setStaffList(updated);
    syncDatabaseWithLocalStorage({ staffList: updated });
  };

  const handleDeletePayment = (id: string) => {
    const updated = payments.filter(p => p.id !== id);
    setPayments(updated);
    syncDatabaseWithLocalStorage({ payments: updated });
  };

  const handleDeleteBook = (id: string) => {
    const updated = books.filter(b => b.id !== id);
    setBooks(updated);
    syncDatabaseWithLocalStorage({ books: updated });
  };


  // MUTATIONS: SETTINGS / BACKUP / RESTORE
  const handleUpdateSettings = (settings: SchoolSettings) => {
    setSchoolSettings(settings);
    syncDatabaseWithLocalStorage({ schoolSettings: settings });
  };

  const handleBackupDatabase = () => {
    const compiledState = {
      schoolSettings,
      classes,
      sections,
      subjects,
      students,
      staffList,
      attendanceLogs,
      exams,
      marks,
      feeCategories,
      feeStructures,
      payments,
      books,
      borrowings,
      timetable,
      auditLogs
    };

    const fileText = JSON.stringify(compiledState, null, 2);
    const blobObj = new Blob([fileText], { type: 'application/json' });
    const localUrl = URL.createObjectURL(blobObj);
    
    // Auto-download link trigger
    const link = document.createElement('a');
    link.href = localUrl;
    link.download = `al-irshaad-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(localUrl);

    handleLogAction('BACKUP_DATABASE', 'Database', 'ALL', 'Exported full school system database backup locally.');
  };

  const handleRestoreDatabase = (dbState: any): boolean => {
    if (!dbState) return false;
    
    // Repopulate state variables
    if (dbState.schoolSettings) setSchoolSettings(dbState.schoolSettings);
    if (dbState.classes) setClasses(dbState.classes);
    if (dbState.sections) setSections(dbState.sections);
    if (dbState.subjects) setSubjects(dbState.subjects);
    if (dbState.students) setStudents(dbState.students);
    if (dbState.staffList) setStaffList(dbState.staffList);
    if (dbState.attendanceLogs) setAttendanceLogs(dbState.attendanceLogs);
    if (dbState.exams) setExams(dbState.exams);
    if (dbState.marks) setMarks(dbState.marks);
    if (dbState.feeCategories) setFeeCategories(dbState.feeCategories);
    if (dbState.feeStructures) setFeeStructures(dbState.feeStructures);
    if (dbState.payments) setPayments(dbState.payments);
    if (dbState.books) setBooks(dbState.books);
    if (dbState.borrowings) setBorrowings(dbState.borrowings);
    if (dbState.timetable) setTimetable(dbState.timetable);
    if (dbState.auditLogs) setAuditLogs(dbState.auditLogs);

    // Write directly to local storage to persist the restored file
    localStorage.setItem(LOCAL_STORAGE_DB_KEY, JSON.stringify(dbState));
    return true;
  };

  const handleResetDatabaseToDefault = () => {
    localStorage.removeItem(LOCAL_STORAGE_DB_KEY);
    
    // Repopulate default state
    setSchoolSettings(INITIAL_SETTINGS);
    setClasses(INITIAL_CLASSES);
    setSections(INITIAL_SECTIONS);
    setSubjects(INITIAL_SUBJECTS);
    setStudents(INITIAL_STUDENTS);
    setStaffList(INITIAL_STAFF);
    setAttendanceLogs(INITIAL_ATTENDANCE);
    setExams(INITIAL_EXAMS);
    setMarks(INITIAL_MARKS);
    setFeeCategories(INITIAL_FEE_CATEGORIES);
    setFeeStructures(INITIAL_FEE_STRUCTURES);
    setPayments(INITIAL_PAYMENTS);
    setBooks(INITIAL_BOOKS);
    setBorrowings(INITIAL_BORROWINGS);
    setTimetable(INITIAL_TIMETABLE);
    setAuditLogs(INITIAL_AUDIT_LOGS);

    handleLogAction('RESTORE_FACTORY_RESETS', 'Settings', 'ALL', 'Reverted database to Mogadishu reference templates.');
  };

  const handleLogin = (userId: string) => {
    const found = INITIAL_USERS.find(u => u.id === userId);
    if (found) {
      setActiveUser(found);
      setIsLoggedIn(true);
      localStorage.setItem('al_irshaad_is_logged_in', 'true');
      localStorage.setItem('al_irshaad_logged_in_user_id', found.id);
      handleLogAction('AUTH_LOGIN', 'Users', found.id, `User ${found.firstName} logged in via authentication screen.`);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.setItem('al_irshaad_is_logged_in', 'false');
    localStorage.removeItem('al_irshaad_logged_in_user_id');
    handleLogAction('AUTH_LOGOUT', 'Users', activeUser.id, `User ${activeUser.firstName} logged out.`);
  };


  // COMPREHENSIVE DASHBOARD METRIC CALCULATIONS
  const totalEnrolled = students.filter(s => s.isActive).length;
  const totalStaff = staffList.length;
  
  // Total Tuition collected this academic year
  const totalTuitionRevenue = payments
    .filter(p => p.categoryId === 'FC-01')
    .reduce((sum, item) => sum + item.amountPaid, 0);

  // Total library books actively on checkout (borrowed and not returned)
  const currentIssuedBooks = borrowings.filter(b => !b.isReturned).length;

  // Track today's student attendance rate
  // Let's search logs for today: 2026-06-01
  const todaysAttendanceLogs = attendanceLogs.filter(log => log.date === '2026-06-01');
  const presentCount = todaysAttendanceLogs.filter(log => log.status === AttendanceStatus.PRESENT).length;
  const attendanceRate = todaysAttendanceLogs.length > 0 
    ? Math.round((presentCount / todaysAttendanceLogs.length) * 100) 
    : 100; // Defaults to 100% outstanding

  if (!isLoggedIn) {
    return <LoginPage users={users} onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 text-slate-800 antialiased overflow-hidden font-sans relative">
      {/* MOBILE TRIGGER MODAL DRAWER (SLIDE-IN SIDEBAR) */}
      <div className={`fixed inset-0 z-50 md:hidden transition-all duration-300 ${isMobileOpen ? 'visible' : 'invisible'}`}>
        {/* Backdrop overlay */}
        <div 
          className={`absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300 ${isMobileOpen ? 'opacity-100' : 'opacity-0'}`}
          onClick={() => setIsMobileOpen(false)}
        />
        
        {/* Sliding panel drawer container */}
        <aside className={`absolute bottom-0 top-0 left-0 w-64 bg-slate-900 text-[#cbd5e1] flex flex-col justify-between shadow-2xl transition-transform duration-300 ease-in-out ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex flex-col h-full">
            {/* Header / close drawer button */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-900 font-extrabold text-sm tracking-tight shadow-sm shrink-0">
                  AR
                </div>
                <div>
                  <h2 className="text-white text-sm font-bold font-sans tracking-wide leading-tight uppercase">Al-irshaad</h2>
                  <p className="text-[10px] text-emerald-400 font-bold tracking-wider uppercase mt-1">● Mobile Portal</p>
                </div>
              </div>
              <button 
                onClick={() => setIsMobileOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-850 rounded-lg cursor-pointer transition-all flex items-center justify-center border border-slate-800 bg-slate-950"
                aria-label="Close Mobile Sidebar"
              >
                <X size={15} />
              </button>
            </div>

            {/* Mobile Nav items */}
            <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
              <button
                onClick={() => { setActiveTab('dashboard'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'dashboard' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <LayoutDashboard size={16} />
                <span>Dashboard Indicators</span>
              </button>

              <button
                onClick={() => { setActiveTab('students'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'students' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <Users size={16} />
                <span>Student Admissions</span>
              </button>

              <button
                onClick={() => { setActiveTab('staff'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'staff' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <UserCheck size={16} />
                <span>Teacher Directory</span>
              </button>

              <button
                onClick={() => { setActiveTab('academics'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'academics' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <GraduationCap size={16} />
                <span>Academic Scoring</span>
              </button>

              <button
                onClick={() => { setActiveTab('finance'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'finance' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <Coins size={16} />
                <span>Fee Billing Ledgers</span>
              </button>

              <button
                onClick={() => { setActiveTab('library'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'library' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <BookOpen size={16} />
                <span>Library Register</span>
              </button>

              <button
                onClick={() => { setActiveTab('settings'); setIsMobileOpen(false); }}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  activeTab === 'settings' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
              >
                <Settings size={16} />
                <span>Settings & backups</span>
              </button>
            </nav>
          </div>

          <div className="p-4 border-t border-slate-850 bg-slate-950 flex flex-col gap-1.5 leading-tight">
            <span className="text-[10px] text-gray-500 font-semibold uppercase">Platform Workspace ID</span>
            <span className="text-[10.5px] text-slate-400 font-mono tracking-tight font-medium overflow-hidden text-ellipsis">83512c0a-e51e-442b</span>
          </div>
        </aside>
      </div>

      {/* SIDE NAVIGATION COLUMN */}
      <aside className={`bg-slate-900 text-[#cbd5e1] ${isSidebarHidden ? 'hidden' : 'hidden md:flex'} flex-col justify-between shrink-0 transition-all duration-300 ease-in-out ${
        isSidebarCollapsed ? 'w-20' : 'w-64'
      }`}>
        <div className="flex flex-col h-full justify-between">
          <div>
            {/* Dashboard branding and status logs */}
            <div className={`p-6 border-b border-slate-800 flex items-center gap-3 ${
              isSidebarCollapsed ? 'justify-center px-2' : ''
            }`}>
              <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-900 font-extrabold text-sm tracking-tight shadow-sm shrink-0">
                AR
              </div>
              {!isSidebarCollapsed && (
                <div className="animate-in fade-in duration-305">
                  <h2 className="text-white text-sm font-bold font-sans tracking-wide leading-tight uppercase">Al-irshaad School</h2>
                  <p className="text-[10px] text-emerald-400 font-bold tracking-wider uppercase mt-1">● Offline Console</p>
                </div>
              )}
            </div>

            {/* Module navigation buttons */}
            <nav className="p-4 space-y-1.5">
              {/* Dashboard summary tab */}
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'dashboard' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Dashboard Indicators"
              >
                <LayoutDashboard size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Dashboard Indicators</span>}
              </button>

              {/* Students tab */}
              <button
                onClick={() => setActiveTab('students')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'students' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Student Admissions"
              >
                <Users size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Student Admissions</span>}
              </button>

              {/* Staff directory tab */}
              <button
                onClick={() => setActiveTab('staff')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'staff' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Teacher Directory"
              >
                <UserCheck size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Teacher Directory</span>}
              </button>

              {/* Academic tab */}
              <button
                onClick={() => setActiveTab('academics')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'academics' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Academic Scoring"
              >
                <GraduationCap size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Academic Scoring</span>}
              </button>

              {/* Fee collections tab */}
              <button
                onClick={() => setActiveTab('finance')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'finance' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Fee Billing Ledgers"
              >
                <Coins size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Fee Billing Ledgers</span>}
              </button>

              {/* Library modules tab */}
              <button
                onClick={() => setActiveTab('library')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'library' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Library Register"
              >
                <BookOpen size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Library Register</span>}
              </button>

              {/* System config tab */}
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0' : 'justify-start'
                } ${
                  activeTab === 'settings' 
                    ? 'bg-white/10 text-white font-bold ring-1 ring-white/10' 
                    : 'hover:bg-slate-850 hover:text-white text-slate-400'
                }`}
                title="Settings & backups"
              >
                <Settings size={16} className="shrink-0" />
                {!isSidebarCollapsed && <span className="animate-in fade-in duration-200">Settings & backups</span>}
              </button>
            </nav>
          </div>

          <div>
            {/* Collapse / Hide Toggle Buttons */}
            <div className={`px-4 py-2 border-t border-slate-800 flex gap-2 ${
              isSidebarCollapsed ? 'flex-col items-center px-2' : 'justify-between'
            }`}>
              <button
                type="button"
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                className={`flex-1 flex items-center gap-2 py-1.5 px-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-850 transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'justify-center px-0 w-8 h-8' : ''
                }`}
                title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
              >
                {isSidebarCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
                {!isSidebarCollapsed && <span>Collapse</span>}
              </button>

              <button
                type="button"
                onClick={() => setIsSidebarHidden(true)}
                className={`flex items-center justify-center gap-2 py-1.5 px-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-rose-400 hover:bg-rose-950/20 transition-all cursor-pointer ${
                  isSidebarCollapsed ? 'w-8 h-8 px-0' : ''
                }`}
                title="Permanently Hide Sidebar (Toggle back from header)"
              >
                <Columns size={14} />
                {!isSidebarCollapsed && <span>Hide</span>}
              </button>
            </div>

            {/* Footer branding of Console */}
            <div className={`p-4 border-t border-slate-850 bg-slate-950 flex flex-col gap-1.5 leading-tight ${
              isSidebarCollapsed ? 'items-center text-center' : ''
            }`}>
              {isSidebarCollapsed ? (
                <span className="text-[10px] text-slate-500 font-mono font-bold" title="Workspace ID: 83512c0a">AR</span>
              ) : (
                <>
                  <span className="text-[10px] text-gray-500 font-semibold uppercase">Platform Workspace ID</span>
                  <span className="text-[10.5px] text-slate-400 font-mono tracking-tight font-medium overflow-hidden text-ellipsis">83512c0a-e51e-442b</span>
                </>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* PRIMARY CONSOLE CONTENT AREA */}
      <div className="flex-1 flex flex-col overflow-hidden">
        
        {/* HEADER ACTION CONTROLS BAR */}
        <header className="bg-white border-b border-gray-150 h-16 shrink-0 flex items-center justify-between px-4 md:px-8">
          <div className="flex items-center gap-2 md:gap-2.5">
            <button
              onClick={() => setIsMobileOpen(true)}
              className="md:hidden p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-all flex items-center justify-center shrink-0 border border-slate-200 bg-slate-50 shadow-xs mr-0.5"
              title="Open Navigation Menu"
            >
              <Menu size={16} />
            </button>
            <button
              onClick={() => setIsSidebarHidden(!isSidebarHidden)}
              className="hidden md:flex p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors items-center justify-center border border-slate-200 bg-slate-50 shadow-xs mr-1"
              title={isSidebarHidden ? "Show Sidebar menu" : "Hide Sidebar menu"}
              id="desktop-sidebar-toggle-btn"
            >
              <Columns size={15} className={isSidebarHidden ? "text-slate-400" : "text-slate-800"} />
            </button>
            <span className="text-sm font-bold text-gray-900 tracking-tight font-sans uppercase">
              {schoolSettings.schoolName}
            </span>
            <span className="text-gray-300 text-sm">/</span>
            <span className="text-xs bg-slate-100 px-2 py-0.5 rounded font-mono font-bold text-slate-800 uppercase tracking-widest">{schoolSettings.academicYear} TERM</span>
          </div>

          <div className="flex items-center gap-4">
            {/* Realtime Somalia Date Indicator */}
            <div className="hidden md:flex items-center gap-2 text-xs text-gray-500 font-sans border-r border-gray-150 pr-4 mt-0.5">
              <Clock size={14} className="text-gray-400" />
              <span>Mogadishu Clock:</span>
              <strong className="text-slate-800 font-semibold">2026-06-01 (15:27 EAT)</strong>
            </div>

            {/* Logged in User Profile & Logout Action */}
            <div className="flex items-center gap-3 pl-1">
              <div className="flex items-center gap-2.5">
                <img
                  src={activeUser.avatarUrl}
                  alt={`${activeUser.firstName} avatar`}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full border border-gray-250 object-cover"
                />
                <div className="hidden lg:block text-left leading-none mt-0.5">
                  <p className="text-xs font-bold text-gray-900">{activeUser.firstName} {activeUser.lastName}</p>
                  <p className="text-[10px] text-gray-400 font-semibold mt-0.5">{activeUser.role}</p>
                </div>
              </div>

              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 transition-colors font-semibold py-1.5 px-3 rounded-lg text-xs border border-rose-100/40 cursor-pointer"
                title="Sign out of administrative session"
                id="user-logout-btn"
              >
                <LogOut size={12} />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </header>

        {/* INNER EXECUTOR VIEWER SCROLLPANEL */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto h-full">

            {activeTab === 'dashboard' && (
              /* DASHBOARD CONSOLE SUMMARY PANEL */
              <div className="space-y-8 animate-in fade-in duration-250">
                {/* Banner briefing greeting */}
                <div className="bg-slate-900 rounded-2xl p-6 text-white relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-sm">
                  <div className="space-y-1 z-10 font-sans">
                    <span className="text-[10px] text-slate-300 font-bold uppercase tracking-wider">Welcome {activeUser.role} · {activeUser.firstName} {activeUser.lastName}</span>
                    <h2 className="text-2xl font-bold tracking-tight">AL-irshaad Administrative Center</h2>
                    <p className="text-xs text-slate-400 max-w-xl">Offline localized platform configured for Mogadishu administrative branches. Hydrated from secure localized browser storage schemas.</p>
                  </div>
                  <div className="flex items-center gap-3 bg-white/10 p-3 rounded-xl border border-white/5 z-10 text-xs">
                    <Database size={15} className="text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-white">Browser Local Storage</p>
                      <p className="text-slate-400 text-[10px]">Data is safely backed up locally.</p>
                    </div>
                  </div>
                </div>

                {/* Primary Stats Bento Grid row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Total Students Card */}
                  <div className="bg-white rounded-xl border border-gray-150 p-4 leading-normal flex items-start justify-between shadow-3xs">
                    <div className="space-y-1 font-sans">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider leading-none">Pupils Enrolled</span>
                      <p className="text-2xl font-black text-slate-900 mt-1">{totalEnrolled} Pupils</p>
                      <span className="text-[10.5px] text-gray-400 block pt-1">Active Grade 9–12 registers</span>
                    </div>
                    <div className="w-10 h-10 bg-slate-100 text-slate-900 flex items-center justify-center rounded-xl">
                      <Users size={18} />
                    </div>
                  </div>

                  {/* Total Personnel Card */}
                  <div className="bg-white rounded-xl border border-gray-150 p-4 leading-normal flex items-start justify-between shadow-3xs">
                    <div className="space-y-1 font-sans">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider leading-none">Administrative Staff</span>
                      <p className="text-2xl font-black text-slate-900 mt-1">{totalStaff} Faculty</p>
                      <span className="text-[10.5px] text-gray-400 block pt-1">Subjects assignments mapped</span>
                    </div>
                    <div className="w-10 h-10 bg-slate-100 text-slate-900 flex items-center justify-center rounded-xl">
                      <UserCheck size={18} />
                    </div>
                  </div>

                  {/* Registered Collections Card */}
                  <div className="bg-white rounded-xl border border-gray-150 p-4 leading-normal flex items-start justify-between shadow-3xs">
                    <div className="space-y-1 font-sans">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider leading-none">Tuition Collected</span>
                      <p className="text-2xl font-black text-slate-900 mt-1">USD {totalTuitionRevenue.toFixed(2)}</p>
                      <span className="text-[10.5px] text-gray-400 block pt-1">Annual Tuition dues settled</span>
                    </div>
                    <div className="w-10 h-10 bg-slate-100 text-slate-950 flex items-center justify-center rounded-xl">
                      <Coins size={18} />
                    </div>
                  </div>

                  {/* Library checked out */}
                  <div className="bg-white rounded-xl border border-gray-150 p-4 leading-normal flex items-start justify-between shadow-3xs">
                    <div className="space-y-1 font-sans">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider leading-none">Books Checked Out</span>
                      <p className="text-2xl font-black text-slate-900 mt-1">{currentIssuedBooks} Volumes</p>
                      <span className="text-[10.5px] text-gray-400 block pt-1">Checking active borrowing timelines</span>
                    </div>
                    <div className="w-10 h-10 bg-slate-100 text-slate-950 flex items-center justify-center rounded-xl">
                      <BookOpen size={18} />
                    </div>
                  </div>
                </div>

                {/* Grid chart analysis & Quick Tasks row */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Left block: Revenue collection breakdown dynamic */}
                  <div className="lg:col-span-2 bg-white rounded-xl border border-gray-150 p-5 space-y-4 shadow-3xs">
                    <div className="border-b border-gray-50 pb-3">
                      <h3 className="font-bold text-slate-900 text-sm font-sans flex items-center gap-1.5">
                        <TrendingUp size={15} />
                        <span>Annual School Cash Allocation Breakdown</span>
                      </h3>
                      <p className="text-xs text-gray-400 mt-0.5">Computed ratios contrasting collected tuition versus remaining debits ledger.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                      <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-100">
                        <p className="text-[10px] font-bold uppercase text-gray-400">Total Assessed Fees</p>
                        <p className="text-xl font-bold mt-1 text-slate-900">USD 6,580</p>
                      </div>
                      <div className="bg-emerald-50 p-3.5 rounded-lg border border-emerald-100">
                        <p className="text-[10px] font-bold uppercase text-emerald-600">Total Settled Cash</p>
                        <p className="text-xl font-bold mt-1 text-emerald-700">USD {payments.reduce((s,i)=>s+i.amountPaid,0)}</p>
                      </div>
                      <div className="bg-red-50 p-3.5 rounded-lg border border-red-50">
                        <p className="text-[10px] font-bold uppercase text-red-600">Outstanding Balance</p>
                        <p className="text-xl font-bold mt-1 text-red-700">USD {6580 - payments.reduce((s,i)=>s+i.amountPaid,0)}</p>
                      </div>
                    </div>

                    {/* Highly polished proportional custom layout charts */}
                    <div className="space-y-3.5 pt-2">
                      <div>
                        <div className="flex justify-between text-xs font-semibold text-gray-600 mb-1">
                          <span>Tuition Collections Settlement Ratio</span>
                          <span>{Math.round((payments.reduce((s,i)=>s+i.amountPaid,0) / 6580) * 100)}% Complete</span>
                        </div>
                        <div className="w-full bg-gray-150 h-2.5 rounded-full overflow-hidden">
                          <div 
                            style={{ width: `${(payments.reduce((s,i)=>s+i.amountPaid,0) / 6580) * 100}%` }}
                            className="bg-slate-900 h-full rounded-full transition-all duration-500"
                          ></div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center text-[11px] text-gray-400 border-t border-gray-50 pt-3">
                        <p>Total logged payments: {payments.length} receipts verified</p>
                        <p>EVC Plus & Bank ledger audited</p>
                      </div>
                    </div>
                  </div>

                  {/* Right block: Quick Navigation / System status */}
                  <div className="lg:col-span-1 bg-white rounded-xl border border-gray-150 p-5 space-y-4 shadow-3xs">
                    <h3 className="font-bold text-slate-900 text-sm border-b border-gray-50 pb-3">
                      Administrative Checklists
                    </h3>

                    <div className="space-y-2.5 text-xs text-slate-700 leading-normal">
                      <div className="flex items-center gap-2.5 p-2 bg-slate-50 border border-slate-100 rounded-lg">
                        <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0"></span>
                        <div className="flex-1">
                          <strong className="text-slate-900 font-semibold block text-[11.5px]">Daily Attendance</strong>
                          <span className="text-[10.5px] text-gray-400 font-medium">Student registers marked for Grade 9</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2.5 p-2 bg-slate-50 border border-slate-100 rounded-lg">
                        <span className="h-2 w-2 rounded-full bg-amber-500 shrink-0"></span>
                        <div className="flex-1">
                          <strong className="text-slate-900 font-semibold block text-[11.5px]">Exam Assessments</strong>
                          <span className="text-[10.5px] text-gray-400 font-medium">{exams.length} terminal modules cataloged</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2.5 p-2 bg-slate-50 border border-slate-100 rounded-lg">
                        <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0"></span>
                        <div className="flex-1">
                          <strong className="text-slate-900 font-semibold block text-[11.5px]">Library Audits</strong>
                          <span className="text-[10.5px] text-gray-400 font-medium">{borrowings.filter(b=>!b.isReturned).length} reference items checked out</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'students' && (
              <StudentModule
                students={students}
                classes={classes}
                sections={sections}
                activeUser={activeUser}
                onAddStudent={handleAddStudent}
                onUpdateStudent={handleUpdateStudent}
                onPromoteStudent={handlePromoteStudent}
                onDeleteStudent={handleDeleteStudent}
                onLogAction={handleLogAction}
              />
            )}

            {activeTab === 'staff' && (
              <TeacherModule
                staffList={staffList}
                subjects={subjects}
                activeUser={activeUser}
                onAddStaff={handleAddStaff}
                onUpdateStaff={handleUpdateStaff}
                onDeleteStaff={handleDeleteStaff}
                onLogAction={handleLogAction}
              />
            )}

            {activeTab === 'academics' && (
              <AcademicModule
                students={students}
                classes={classes}
                sections={sections}
                subjects={subjects}
                exams={exams}
                marks={marks}
                attendanceLogs={attendanceLogs}
                activeUser={activeUser}
                schoolSettings={schoolSettings}
                onRecordAttendance={handleRecordAttendance}
                onRecordMarks={handleRecordMarks}
                onAddExam={handleAddExam}
                onLogAction={handleLogAction}
              />
            )}

            {activeTab === 'finance' && (
              <FinanceModule
                students={students}
                classes={classes}
                feeCategories={feeCategories}
                feeStructures={feeStructures}
                payments={payments}
                activeUser={activeUser}
                onRecordPayment={handleRecordPayment}
                onAddFeeCategory={handleAddFeeCategory}
                onDeletePayment={handleDeletePayment}
                onLogAction={handleLogAction}
              />
            )}

            {activeTab === 'library' && (
              <LibraryModule
                books={books}
                borrowings={borrowings}
                students={students}
                activeUser={activeUser}
                onAddBook={handleAddBook}
                onIssueBook={handleIssueBook}
                onReturnBook={handleReturnBook}
                onDeleteBook={handleDeleteBook}
                onLogAction={handleLogAction}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsModule
                schoolSettings={schoolSettings}
                auditLogs={auditLogs}
                activeUser={activeUser}
                onUpdateSettings={handleUpdateSettings}
                onBackupDatabase={handleBackupDatabase}
                onRestoreDatabase={handleRestoreDatabase}
                onResetDatabaseToDefault={handleResetDatabaseToDefault}
                onLogAction={handleLogAction}
              />
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
